#!/usr/bin/env python3
"""Studio TTS — OmniVoice + faster-whisper 的 Studio 适配层。

把 tts-skill（https://github.com/boommanpro/tts-skill）包装成 Studio 世界内
可直接调用的命令行：环境一键安装、语音生成、音频/视频转文字，并把产出落到
works/audio/<slug>/ 目录（语音附带可发布的播放页）。

用法：
  python studio_tts.py setup [--with_asr] [--force]
  python studio_tts.py voice --text "..." [选项]
  python studio_tts.py transcribe --input <file> [选项]
  python studio_tts.py history [--type tts|asr|all] [--show_cmd]
  python studio_tts.py doctor
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

# 让 vendored tts_skill 包可导入（本文件位于 scripts/ 下）
SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

# 技能自带运行环境（避免污染系统 Python / 绕过 PEP 668）
VENV_DIR = SCRIPTS_DIR / ".venv"
VENV_PY = VENV_DIR / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def _in_venv() -> bool:
    try:
        return Path(sys.prefix).resolve() == VENV_DIR.resolve()
    except OSError:
        return False


def _bootstrap_venv() -> None:
    """若未在技能自带 venv 中运行，则创建/复用 venv 并以 venv python 重执行。"""
    if _in_venv():
        return
    if not VENV_PY.exists():
        print("创建技能运行环境 (.venv)...")
        subprocess.run(
            [sys.executable, "-m", "venv", str(VENV_DIR)],
            check=True,
            capture_output=True,
        )
    print("切换到技能运行环境 (.venv)...")
    os.execv(str(VENV_PY), [str(VENV_PY), str(Path(__file__).resolve())] + sys.argv[1:])


from tts_skill import __version__  # noqa: E402
from tts_skill.utils import (  # noqa: E402
    PROJECT_ROOT,
    detect_torch_device,
    ensure_output_dir,
    gen_random_seed,
    is_setup_done,
    run_subprocess_streaming,
    set_hf_mirror_env,
)

# Studio 产出根目录：workspace/works/audio/
# 优先取环境变量 WORKSPACE_DIR；否则向上找 manifest.json 锚定世界根。
def _find_workspace_root() -> Path:
    env_root = os.environ.get("WORKSPACE_DIR")
    if env_root:
        return Path(env_root)
    cur = Path.cwd()
    for p in [cur, *cur.parents]:
        if (p / "manifest.json").exists():
            return p
    return cur


WORKSPACE_ROOT = _find_workspace_root()
AUDIO_ROOT = WORKSPACE_ROOT / "works" / "audio"

# 播放页模板（无外部依赖，纯 HTML/CSS/JS）
PLAYER_PAGE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<style>
  :root {{
    --bg: #101216; --panel: #181b22; --line: #262b36;
    --ink: #e8e6e0; --muted: #8a8f9c; --accent: #d9a441;
  }}
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ background: var(--bg); color: var(--ink);
    font-family: ui-sans-serif, system-ui, -apple-system, "PingFang SC",
    "Noto Sans SC", "Microsoft YaHei", sans-serif; min-height: 100vh; }}
  .wrap {{ max-width: 720px; margin: 0 auto; padding: 48px 20px 72px; }}
  .kicker {{ color: var(--accent); font-size: 12px; letter-spacing: 0.18em;
    text-transform: uppercase; margin-bottom: 10px; }}
  h1 {{ font-size: 28px; font-weight: 700; margin-bottom: 8px; }}
  .desc {{ color: var(--muted); font-size: 14px; line-height: 1.7;
    margin-bottom: 32px; white-space: pre-wrap; }}
  .track {{ background: var(--panel); border: 1px solid var(--line);
    border-radius: 12px; padding: 16px 18px; margin-bottom: 14px; }}
  .track-head {{ display: flex; align-items: baseline; gap: 10px;
    margin-bottom: 10px; }}
  .track-name {{ font-weight: 600; font-size: 15px; }}
  .track-meta {{ color: var(--muted); font-size: 12px; margin-left: auto; }}
  audio {{ width: 100%; height: 36px; }}
  details {{ margin-top: 8px; }}
  summary {{ color: var(--muted); font-size: 12px; cursor: pointer;
    user-select: none; }}
  pre {{ margin-top: 8px; padding: 10px 12px; background: #0c0e12;
    border: 1px solid var(--line); border-radius: 8px;
    font-size: 11px; line-height: 1.6; color: #9fd08a;
    overflow-x: auto; white-space: pre-wrap; word-break: break-all; }}
  .foot {{ margin-top: 40px; color: var(--muted); font-size: 12px;
    text-align: center; }}
</style>
</head>
<body>
<div class="wrap">
  <div class="kicker">{kicker}</div>
  <h1>{title}</h1>
  <div class="desc">{desc}</div>
  {tracks_html}
  <div class="foot">{foot}</div>
</div>
</body>
</html>
"""

TRACK_TEMPLATE = """  <div class="track">
    <div class="track-head">
      <span class="track-name">{name}</span>
      <span class="track-meta">{meta}</span>
    </div>
    <audio controls preload="none" src="{src}"></audio>
    {cmd_html}
  </div>
"""


def _html_escape(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


# ---------------------------------------------------------------------------
# setup
# ---------------------------------------------------------------------------


def cmd_setup(args: argparse.Namespace) -> int:
    from tts_skill.setup_env import setup_environment

    # setup_environment 内部已实时打印进度（_log flush），这里不再重复打印
    ok, _log = setup_environment(force=args.force, skip_asr=not args.with_asr)
    return 0 if ok else 1


# ---------------------------------------------------------------------------
# 模型注册表（多引擎支持）
# ---------------------------------------------------------------------------

# 默认引擎 ID（可用 voice --model 覆盖）
DEFAULT_ENGINE = "qwen3-tts"


MODEL_REGISTRY: list[dict] = [
    {
        "id": "omnivoice",
        "name": "OmniVoice",
        "license": "Apache-2.0",
        "engine": "omnivoice",
        "venv": ".venv",
        "verified": True,
        "install": "随 setup 自动安装",
        "hf_repo": "k2-fsa/OmniVoice",
        "ms_repo": "k2-fsa/OmniVoice",
        "size": "~5GB",
        "device": "CPU/GPU 均可（CPU 自动 float32）",
        "note": "clone/design/auto 三模式，600+ 语种，CPU 直接可跑",
    },
    {
        "id": "spark-tts",
        "name": "Spark-TTS",
        "license": "Apache-2.0",
        "engine": "spark",
        "venv": ".venv-spark",
        "verified": True,
        "install": "models install spark-tts（git 源码 + HF/ModelScope 权重）",
        "source_git": "https://github.com/SparkAudio/Spark-TTS.git",
        "pip": ["einops", "einx", "omegaconf", "safetensors", "soxr", "tqdm", "soundfile", "numpy", "transformers==4.46.2"],
        "hf_repo": "SparkAudio/Spark-TTS-0.5B",
        "ms_repo": "SparkAudio/Spark-TTS-0.5B",
        "size": "~3.7GB",
        "device": "CPU 友好（无 GPU 可跑）",
        "note": "0.5B（Qwen2.5 架构），中英双语，gender/pitch/speed 控制，16kHz；design 属性仅支持性别/音调/语速",
    },
    {
        "id": "qwen3-tts",
        "name": "Qwen3-TTS",
        "license": "Apache-2.0（默认变体公开免 token；0.6B-VoiceDesign 受限需许可）",
        "engine": "qwen",
        "venv": ".venv-qwen",
        "verified": False,
        "install": "models install qwen3-tts（全部公开变体，免 token）",
        "pip": ["qwen-tts"],
        "hf_repo": "Qwen/Qwen3-TTS-12Hz-0.6B",
        "hf_repos": {
            # 注：0.6B-VoiceDesign 受限（需 token）；design 模式用公开的 0.6B-CustomVoice（speaker + instruct 实现音色设计）
            "design": "Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice",
            "clone": "Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice",
            "auto": "Qwen/Qwen3-TTS-12Hz-0.6B-Base",
        },
        "ms_repo": "Qwen/Qwen3-TTS-12Hz-0.6B",
        "ms_repos": {
            "design": "Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice",
            "clone": "Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice",
            "auto": "Qwen/Qwen3-TTS-12Hz-0.6B-Base",
        },
        "size": "~1.5GB/个变体",
        "device": "GPU 推荐（CPU 慢）",
        "note": "本技能默认引擎；端到端低延迟（~97ms）；0.6B-VoiceDesign 变体受限，design 模式用公开的 0.6B-CustomVoice（speaker+instruct 实现音色设计）；文章作者实测：不能加减速",
    },
    {
        "id": "f5-tts",
        "name": "F5-TTS",
        "license": "MIT",
        "engine": "f5",
        "venv": ".venv-f5",
        "verified": False,
        "install": "models install f5-tts",
        "pip": ["f5-tts"],
        "hf_repo": "SWivid/F5-TTS",
        "ms_repo": "SWivid/F5-TTS",
        "size": "~1.4GB",
        "device": "CPU/GPU（CPU 慢）",
        "note": "0.3B Flow Matching + DiT，纯零样本克隆（必须提供参考音频），MIT 协议最省心",
    },
    {
        "id": "cosyvoice2",
        "name": "CosyVoice 2",
        "license": "Apache-2.0",
        "engine": "manual",
        "venv": None,
        "verified": False,
        "install": "手动：git clone --recursive https://github.com/FunAudioLLM/CosyVoice.git + conda create -n cosyvoice python=3.10 + pip install -r requirements.txt（pynini 用 conda install -y -c conda-forge pynini==2.1.5）",
        "hf_repo": "FunAudioLLM/CosyVoice-2-0.5B",
        "ms_repo": "iic/CosyVoice2-0.5B",  # 魔搭官方 iic 组织，实测 clone + LFS 均匿名可拉
        "size": "~2GB",
        "device": "GPU ~4GB 显存",
        "note": "文章首选：工程成熟度最高，方言支持，流式；权重可从魔搭 iic/CosyVoice2-0.5B 匿名拉取（HF 受限）；引擎需手动 conda 环境",
    },
    {
        "id": "index-tts2",
        "name": "IndexTTS2",
        "license": "Apache-2.0",
        "engine": "manual",
        "venv": None,
        "verified": False,
        "install": "手动：git clone https://github.com/IndexTeam/IndexTTS.git + uv run webui.py（依赖用 uv 管理，不支持 pip/conda 直接装）",
        "hf_repo": "IndexTeam/IndexTTS2",
        "ms_repo": "IndexTeam/IndexTTS-2",  # 魔搭官方仓库，实测 clone + LFS（s2mel.pth 1.2GB）匿名可拉
        "size": "~3GB",
        "device": "GPU FP16 ~7.8GB 显存",
        "note": "7 种情感独立控制 + Token 级时长精确控制；权重可从魔搭 IndexTeam/IndexTTS-2 匿名拉取；引擎需 uv 独立环境 + GPU",
    },
    {
        "id": "fish-speech",
        "name": "Fish Speech 1.5",
        "license": "Apache-2.0",
        "engine": "manual",
        "venv": None,
        "verified": False,
        "install": "手动：conda create -n fish-speech python=3.12.10 + pip install torch==2.8.0 torchaudio==2.8.0 --index-url https://download.pytorch.org/whl/cu126 + git clone https://github.com/fishaudio/fish-speech + git checkout v1.5.1 + pip install -e .（必须 Python 3.12）",
        "hf_repo": "fishaudio/fish-speech-1.5",
        "ms_repo": "fishaudio/fish-speech-1.5",
        "size": "~1GB",
        "device": "GPU ≥4GB（克隆 ≥6GB）",
        "note": "多语言全能，双自回归，情感/韵律精细控制；必须独立 conda 3.12 环境",
    },
]


def _resolve_model(model_id: str) -> dict | None:
    for m in MODEL_REGISTRY:
        if m["id"] == model_id:
            return m
    return None


def _venv_python(model: dict) -> Path:
    if os.name == "nt":
        return SCRIPTS_DIR / model["venv"] / "Scripts" / "python.exe"
    return SCRIPTS_DIR / model["venv"] / "bin" / "python"


def _print_install_guide(model: dict) -> None:
    print(f"模型 {model['id']}（{model['name']}）未就绪。安装方法：")
    print(f"  python3 {SCRIPTS_DIR / 'studio_tts.py'} models install {model['id']}")
    if model["engine"] == "manual":
        print("（手动安装：" + model["install"] + "）")


# ---------------------------------------------------------------------------
# models —— 模型列表 / 状态 / 安装
# ---------------------------------------------------------------------------


def cmd_models(args: argparse.Namespace) -> int:
    action = args.action or "list"

    if action == "list":
        print(f"{'ID':<12} {'名称':<14} {'引擎':<10} {'可用':<6} {'体积':<10} 说明")
        print("-" * 100)
        for m in MODEL_REGISTRY:
            ok_mark = "✓" if m["verified"] else "—"
            print(
                f"{m['id']:<12} {m['name']:<14} {m['engine']:<10} "
                f"{ok_mark:<6} {m['size']:<10} {m['note'][:40]}"
            )
        print()
        print("用 voice --model <ID> 选择引擎；用 models install <ID> 安装。")
        print("可用=该模型已被验证能跑（非本机安装状态）；本机是否就绪看 models status。")
        return 0

    if action == "status":
        for m in MODEL_REGISTRY:
            venv_ok = Path(_venv_python(m)).exists() if m["venv"] else False
            if m["engine"] == "omnivoice":
                # 真实安装状态以 setup 标记为准（import tts_skill 永远成功，不能作判据）
                venv_ok = is_setup_done()
            weights_ok = ""
            spark_weights_dir = SCRIPTS_DIR / "models" / "weights" / "Spark-TTS-0.5B"
            if m["id"] == "spark-tts":
                weights_ok = "✓" if spark_weights_dir.is_dir() else "—"
            src_ok = "✓" if (SCRIPTS_DIR / "models" / "Spark-TTS-src").is_dir() else "—"
            venv_mark = "✓" if venv_ok else "—"
            src_mark = "✓" if m["id"] == "spark-tts" and src_ok else ("—" if m["engine"] == "manual" else "n/a")
            # 就绪 = 当前环境可直接生成（注册表 verified 只代表“曾在某处跑通”，不作本地判据）
            if m["engine"] == "manual":
                ready_mark = "—"
            elif m["id"] == "omnivoice":
                ready_mark = "✓" if is_setup_done() else "—"
            elif m["id"] == "spark-tts":
                ready_mark = "✓" if venv_ok and src_ok and spark_weights_dir.is_dir() else "—"
            else:  # qwen3-tts / f5-tts：venv 就绪即权重首次生成自动下载
                ready_mark = "✓" if venv_ok else "—"
            print(
                f"{m['id']:<12} venv={venv_mark}  "
                f"源码={src_mark}  "
                f"权重={weights_ok or 'n/a'}  就绪={ready_mark}"
            )
        return 0

    if action == "install":
        model = _resolve_model(args.model_id)
        if model is None:
            print(f"[错误] 未知模型: {args.model_id}。可用: {', '.join(m['id'] for m in MODEL_REGISTRY)}")
            return 1
        source = args.source or ("modelscope" if os.environ.get("MODELSCOPE_HUB") == "1" else "hf")
        if model["engine"] == "manual":
            print(f"模型 {model['id']}（{model['name']}）需要手动安装（conda/独立环境）：")
            print(model["install"])
            return 0
        return _install_external_model(model, source)

    print(f"[错误] 未知操作: {action}（可用 list/status/install）")
    return 1


def _pip_venv(venv_py: Path, pkgs: list[str], extra: list[str] | None = None) -> tuple[bool, str]:
    # --progress-bar off：非 TTY 下 pip 进度条会刷屏；实时流式输出便于区分下载中/卡死
    cmd = [str(venv_py), "-m", "pip", "install", "--progress-bar", "off"] + pkgs + (extra or [])
    return run_subprocess_streaming(cmd)


def _install_external_model(model: dict, source: str = "hf") -> int:
    vid = model["id"]
    venv_py = _venv_python(model)
    print(f"[1/3] 创建环境 {model['venv']} ...")
    if not Path(venv_py).exists():
        subprocess.run([sys.executable, "-m", "venv", str(SCRIPTS_DIR / model["venv"])], check=True)
    # 旧版 pip（ensurepip 自带 23.x）在 PIP_USER 注入的环境里直接报 --user 错误，
    # 且在 --index-url 指向专用源时无法解析构建依赖（flit_core 等）；先升级 pip。
    print("[1.5/3] 升级 pip ...")
    ok, log = _pip_venv(venv_py, ["--upgrade", "pip"])
    if not ok:
        print("pip 升级失败（继续尝试安装）:\n" + log)
    print(f"[2/3] 安装依赖（torch CPU + 模型包）...")
    ok, log = _pip_venv(
        venv_py,
        ["torch==2.8.0+cpu", "torchaudio==2.8.0+cpu"],
        extra=["--index-url", "https://download.pytorch.org/whl/cpu"],
    )
    if not ok:
        print("torch 安装失败:\n" + log)
        return 1
    # 依赖清单优先读 scripts/requirements-<id>.txt，缺失时回退注册表内嵌列表
    req_file = SCRIPTS_DIR / f"requirements-{vid}.txt"
    pkgs = model.get("pip", [])
    if req_file.exists():
        pkgs = [
            l.strip()
            for l in req_file.read_text(encoding="utf-8").splitlines()
            if l.strip() and not l.strip().startswith("#")
        ]
    ok, log = _pip_venv(venv_py, pkgs)
    if not ok:
        print(f"依赖安装失败:\n{log}")
        return 1
    print(f"[3/3] 下载模型权重（{source}） ...")
    if vid == "spark-tts":
        src_dir = SCRIPTS_DIR / "models" / "Spark-TTS-src"
        if not src_dir.is_dir():
            print("  克隆源码 https://github.com/SparkAudio/Spark-TTS.git ...")
            subprocess.run(["git", "clone", "--depth", "1", "https://github.com/SparkAudio/Spark-TTS.git", str(src_dir)], check=True)
        repos = _pick_repos(model, source)
        repo = repos["default"] if repos else None
        if repo:
            dl = _download_ms if source == "modelscope" else _download_hf
            dl(repo, local_dir=str(SCRIPTS_DIR / "models" / "weights" / "Spark-TTS-0.5B"))
    elif vid == "qwen3-tts":
        repos = _pick_repos(model, source)
        if not repos:
            print("  [错误] 该模型没有可用的仓库映射")
            return 1
        # v2.5+：默认变体（CustomVoice / Base）在 HF 与魔搭均公开、免 token，
        # 首次 voice --model qwen3-tts 按模式自动拉取，无需在此强制下载。
        print("  默认变体权重公开（Qwen3-TTS-12Hz-0.6B-CustomVoice / -Base，HF + 魔搭均可匿名拉取）")
        print("  首次 voice --model qwen3-tts 生成时自动下载对应变体（免 token）。")
        print("  注：0.6B-VoiceDesign 变体受限，需登录接受许可 + HF_TOKEN / MODELSCOPE_API_TOKEN。")
        if source == "modelscope":
            if os.environ.get("MODELSCOPE_API_TOKEN"):
                print("  检测到 MODELSCOPE_API_TOKEN：额外预下载三个变体权重...")
                for mode, repo in repos.items():
                    target = str(SCRIPTS_DIR / "models" / "weights" / f"Qwen3-TTS-{mode}")
                    print(f"    {repo} → {target}")
                    _download_ms(repo, local_dir=target)
        elif os.environ.get("HF_TOKEN"):
            print("  检测到 HF_TOKEN：额外预下载三个变体权重（design/clone/auto）...")
            for mode, repo in repos.items():
                target = str(SCRIPTS_DIR / "models" / "weights" / f"Qwen3-TTS-{mode}")
                print(f"    {repo} → {target}")
                _download_hf(repo, local_dir=target)
    elif vid == "f5-tts":
        print("  首次 voice --model f5-tts 生成时会自动下载 SWivid/F5-TTS 权重。")
    print(f"模型 {vid}（{model['name']}）安装完成。用 voice --model {vid} 使用。")
    return 0


def _download_hf(repo: str, local_dir: str) -> None:
    from huggingface_hub import snapshot_download

    env = dict(os.environ)
    # 尊重用户显式设置的 HF_ENDPOINT（如国内镜像站）；未设置则默认直连 huggingface.co
    env.setdefault("HF_ENDPOINT", "https://huggingface.co")
    env["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
    snapshot_download(repo, local_dir=local_dir, local_dir_use_symlinks=False)


def _download_ms(repo: str, local_dir: str) -> None:
    """从 ModelScope（魔搭）下载模型权重，自动处理 LFS。

    受限仓库需设置 MODELSCOPE_API_TOKEN 且已在魔搭模型页接受协议。
    """
    from modelscope import snapshot_download

    snapshot_download(repo, local_dir=local_dir)


def _pick_repos(model: dict, source: str) -> dict | None:
    """按下载源返回 {mode: repo} 映射。

    source: 'hf' | 'modelscope' | 自动（MODELSCOPE_HUB=1 时用魔搭）
    """
    if source == "modelscope":
        return model.get("ms_repos") or ({"default": model["ms_repo"]} if model.get("ms_repo") else None)
    return model.get("hf_repos") or ({"default": model["hf_repo"]} if model.get("hf_repo") else None)


def _ensure_external_ready(model: dict) -> tuple[bool, str]:
    """检查外部后端是否就绪，返回 (ok, 提示)。"""
    if not Path(_venv_python(model)).exists():
        return False, f"模型 {model['id']} 环境未安装。"
    if model["id"] == "spark-tts":
        if not (SCRIPTS_DIR / "models" / "Spark-TTS-src").is_dir():
            return False, f"模型 {model['id']} 源码缺失。"
        if not (SCRIPTS_DIR / "models" / "weights" / "Spark-TTS-0.5B").is_dir():
            return False, f"模型 {model['id']} 权重缺失。"
    # qwen3-tts 默认变体（0.6B-CustomVoice / 0.6B-Base）在 HF 与魔搭公开、免 token；
    # 仅 0.6B-VoiceDesign 受限（需 token），若用户改指受限变体，runner 会报 HF 的明确错误。
    return True, ""


# ---------------------------------------------------------------------------
# voice —— 生成语音并落成可发布的音频作品
# ---------------------------------------------------------------------------


def _ensure_setup(need_asr: bool = False) -> bool:
    """确保环境已安装；需要 ASR 时单独校验 faster-whisper。"""
    if not is_setup_done():
        print("环境未安装，自动安装中（首次约 10-20 分钟）...")
        from tts_skill.setup_env import setup_environment

        # setup_environment 内部已实时打印进度
        ok, _log = setup_environment(skip_asr=not need_asr)
        if not ok:
            return False
    set_hf_mirror_env()
    if need_asr:
        try:
            import faster_whisper  # noqa: F401

            import imageio_ffmpeg  # noqa: F401
        except ImportError:
            print("语音转文字依赖未安装，安装中...")
            from tts_skill.setup_env import setup_environment

            ok, _log = setup_environment(skip_asr=False)
            if not ok:
                return False
    return True


def _wav_to_mp3(wav_path: Path) -> Path | None:
    """用 imageio-ffmpeg 自带的 ffmpeg 把 wav 转成 mp3（供网页播放）。"""
    mp3_path = wav_path.with_suffix(".mp3")
    try:
        import subprocess

        import imageio_ffmpeg

        ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
        subprocess.run(
            [
                ffmpeg, "-y", "-i", str(wav_path),
                "-codec:a", "libmp3lame", "-qscale:a", "4",
                str(mp3_path),
            ],
            capture_output=True,
            timeout=120,
            check=True,
        )
        return mp3_path
    except Exception as e:  # noqa: BLE001
        print(f"[警告] wav→mp3 转换失败（保留 wav）: {e}")
        return None


def _build_player_page(
    work_dir: Path,
    *,
    title: str,
    kicker: str,
    desc: str,
    tracks: list[dict],
    foot: str,
) -> Path:
    """生成播放页 index.html。tracks: [{name, meta, src, cmd}]"""
    tracks_html = "\n".join(
        TRACK_TEMPLATE.format(
            name=_html_escape(t["name"]),
            meta=_html_escape(t.get("meta", "")),
            src=t["src"],
            cmd_html=(
                f"<details><summary>可复现命令</summary><pre>{_html_escape(t['cmd'])}</pre></details>"
                if t.get("cmd")
                else ""
            ),
        )
        for t in tracks
    )
    page = PLAYER_PAGE.format(
        title=_html_escape(title),
        kicker=_html_escape(kicker),
        desc=_html_escape(desc),
        tracks_html=tracks_html,
        foot=_html_escape(foot),
    )
    page_path = work_dir / "index.html"
    page_path.write_text(page, encoding="utf-8")
    return page_path


def _run_external_voice(model: dict, args: argparse.Namespace, audio_dir: Path) -> "object":
    """用外部后端 runner 生成语音，返回 GenerationRecord。"""
    from tts_skill.config import create_record

    venv_py = _venv_python(model)
    runner = SCRIPTS_DIR / "backends" / f"run_{model['engine']}.py"
    base_seed = args.seed if args.seed is not None else __import__("random").randint(0, 2**31 - 1)
    batch = max(1, min(5, args.batch_count))
    batch_seeds = [base_seed + i for i in range(batch)]
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    output_files: list[str] = []
    errors: list[str] = []

    env = dict(os.environ)
    env.pop("PIP_USER", None)
    # 尊重用户设置的 HF_ENDPOINT（如国内镜像站）；未设置则直连官方源

    for i, seed in enumerate(batch_seeds):
        suffix = f"_{i}" if batch > 1 else ""
        wav_path = audio_dir / f"{model['id']}_{timestamp}{suffix}_seed{seed}.wav"
        payload = {
            "text": args.text,
            "mode": args.mode,
            "instruct": args.instruct,
            "ref_audio": args.ref_audio,
            "ref_text": args.ref_text,
            "language": args.language,
            "seed": seed,
            "device": args.device or "cpu",
        }
        if model["engine"] == "qwen" and model.get("hf_repos"):
            payload["model_id"] = model["hf_repos"].get(args.mode, model["hf_repo"])
        if model["engine"] == "spark":
            payload["model_dir"] = str(SCRIPTS_DIR / "models" / "weights" / "Spark-TTS-0.5B")
        payload_path = audio_dir / f"_args_{seed}.json"
        payload_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")

        print(f"[{i + 1}/{batch}] {model['name']} 生成中 (seed={seed}, mode={args.mode})...")
        try:
            r = subprocess.run(
                [str(venv_py), str(runner), str(payload_path), str(wav_path)],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=2400,
                env=env,
            )
            out = (r.stdout or "") + (r.stderr or "")
            result = json.loads((r.stdout or "").strip().splitlines()[-1]) if r.stdout.strip() else {}
            if r.returncode == 0 and result.get("ok"):
                output_files.append(str(wav_path))
                print(f"[{i + 1}/{batch}] 已保存: {wav_path.name} ({result.get('duration', '?')}s)")
            else:
                errors.append(f"[seed={seed}] {result.get('error', out[-800:])}")
                print(f"[{i + 1}/{batch}] 生成失败: {result.get('error', out[-400:])}")
        except Exception as e:  # noqa: BLE001
            errors.append(f"[seed={seed}] {type(e).__name__}: {e}")
            print(f"[{i + 1}/{batch}] 生成失败: {e}")
        finally:
            try:
                payload_path.unlink(missing_ok=True)
            except OSError:
                pass

    if not output_files:
        raise RuntimeError("所有生成均失败: " + "; ".join(errors))

    return create_record(
        mode=args.mode,
        text=args.text,
        ref_audio=args.ref_audio,
        ref_text=args.ref_text,
        instruct=args.instruct,
        language=args.language,
        seed=base_seed,
        batch_count=batch,
        batch_seeds=batch_seeds,
        output_files=output_files,
        device=args.device or "cpu",
        name=args.name,
    )


def _finish_voice(
    work_dir: Path,
    audio_dir: Path,
    slug: str,
    args: argparse.Namespace,
    record: "object",
    engine_name: str,
    model_id: str,
) -> int:
    """生成后的公共收尾：mp3 转换、播放页、tracks.json、发布指引。"""
    from tts_skill.config import build_reproducible_command

    def _studio_cmd() -> str:
        parts = ["python3", str(SCRIPTS_DIR / "studio_tts.py"), "voice"]
        parts += ["--text", f'"{args.text}"', "--mode", record.mode]
        parts += ["--seed", str(record.seed)]
        if record.instruct:
            parts += ["--instruct", f'"{record.instruct}"']
        if record.ref_audio:
            parts += ["--ref_audio", f'"{record.ref_audio}"']
        if record.ref_text:
            parts += ["--ref_text", f'"{record.ref_text}"']
        if record.language:
            parts += ["--language", record.language]
        if record.batch_count > 1:
            parts += ["--batch_count", str(record.batch_count)]
        parts += ["--model", model_id]
        parts += ["--slug", slug]
        return " ".join(parts)

    studio_cmd = _studio_cmd()
    track_info: list[dict] = []
    for i, f in enumerate(record.output_files):
        wav = Path(f)
        mp3 = _wav_to_mp3(wav)
        src = f"audio/{mp3.name}" if mp3 else f"audio/{wav.name}"
        seed_i = record.batch_seeds[i] if i < len(record.batch_seeds) else record.seed
        track_info.append(
            {
                "name": f"{record.name} · {i + 1}",
                "meta": f"seed={seed_i} · {record.mode}",
                "src": src,
                "cmd": studio_cmd,
            }
        )

    mode_label = {"auto": "自动声音", "design": "声音设计", "clone": "声音克隆"}.get(
        record.mode, record.mode
    )
    title = args.title or f"{record.name}"
    desc = args.desc or (
        f"文本：{record.text}\n模式：{mode_label}\n引擎：{engine_name}\n"
        f"基础种子：{record.seed}"
        + (f"\n声音属性：{record.instruct}" if record.instruct else "")
        + (f"\n参考音频：{record.ref_audio}" if record.ref_audio else "")
    )
    page = _build_player_page(
        work_dir,
        title=title,
        kicker="STUDIO · TTS VOICE",
        desc=desc,
        tracks=track_info,
        foot=f"tts-skill v{__version__} · {engine_name} · {detect_torch_device()}",
    )
    print(f"播放页: {page}")

    manifest = {
        "work_dir": str(work_dir),
        "title": title,
        "desc": desc,
        "mode": record.mode,
        "text": record.text,
        "seed": record.seed,
        "instruct": record.instruct,
        "engine": engine_name,
        "command": studio_cmd,
        "tracks": [
            {
                "name": t["name"],
                "file": t["src"],
                "seed": int(t["meta"].split("seed=")[1].split(" ")[0]),
            }
            for t in track_info
        ],
    }
    (work_dir / "tracks.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"清单: {work_dir / 'tracks.json'}")
    print("=" * 60)
    print("语音生成完成！下一步（由执行 agent 完成）:")
    print(f"  node /mods/neta/neta work init web works/audio/{slug} --title \"{title}\"")
    print(f"  node /mods/neta/neta work publish web works/audio/{slug}")
    return 0


def cmd_voice(args: argparse.Namespace) -> int:
    # 模型解析：优先匹配注册表 ID；否则视为 OmniVoice 的 HF 仓库覆盖（向后兼容）
    model = _resolve_model(args.model or DEFAULT_ENGINE)
    if model is None:
        # 未注册的 --model 值 → 当作 omnivoice 的模型仓库覆盖
        model = _resolve_model("omnivoice")
        args.model_repo_override = args.model
    else:
        args.model_repo_override = None
    set_hf_mirror_env()

    slug = args.slug or f"voice_{time.strftime('%Y%m%d_%H%M%S')}"
    work_dir = AUDIO_ROOT / slug
    audio_dir = work_dir / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)
    for old in list(audio_dir.glob("*.wav")) + list(audio_dir.glob("*.mp3")):
        try:
            old.unlink()
        except OSError:
            pass
    print(f"工作目录: {work_dir}")
    print(f"音频输出: {audio_dir}")

    if model["engine"] == "omnivoice":
        if not _ensure_setup(need_asr=False):
            print("[错误] 环境安装失败，请先运行: python studio_tts.py setup")
            return 1
        from tts_skill.infer import run_inference
        from tts_skill.utils import DEFAULT_MODEL

        ns = argparse.Namespace(
            text=args.text,
            mode=args.mode,
            ref_audio=args.ref_audio,
            ref_text=args.ref_text,
            instruct=args.instruct,
            language=args.language,
            seed=args.seed,
            num_step=args.num_step,
            speed=args.speed,
            duration=args.duration,
            guidance_scale=args.guidance_scale,
            t_shift=args.t_shift,
            denoise=args.denoise,
            postprocess_output=args.postprocess_output,
            normalize_text=args.normalize_text,
            batch_count=args.batch_count,
            output_dir=str(audio_dir),
            name=args.name,
            model=args.model_repo_override or DEFAULT_MODEL,
            device=args.device,
        )
        rc = run_inference(ns)
        if rc != 0:
            return rc
        from tts_skill.config import load_history

        records = load_history()
        if not records:
            print("[警告] 未找到历史记录")
            return 1
        record = records[0]
        return _finish_voice(work_dir, audio_dir, slug, args, record, "OmniVoice", "omnivoice")

    # 外部后端
    ok, hint = _ensure_external_ready(model)
    if not ok:
        print("[错误] " + hint)
        _print_install_guide(model)
        return 1
    try:
        record = _run_external_voice(model, args, audio_dir)
    except Exception as e:  # noqa: BLE001
        print(f"[错误] 生成失败: {e}")
        return 1
    return _finish_voice(work_dir, audio_dir, slug, args, record, model["name"], model["id"])



# ---------------------------------------------------------------------------
# transcribe —— 音频/视频转文字
# ---------------------------------------------------------------------------


def cmd_transcribe(args: argparse.Namespace) -> int:
    set_hf_mirror_env()
    if not _ensure_setup(need_asr=True):
        print("[错误] 环境安装失败，请先运行: python studio_tts.py setup --with_asr")
        return 1

    from tts_skill.transcribe import run_transcribe

    if args.output_dir is None:
        args.output_dir = str(
            AUDIO_ROOT / f"transcribe_{time.strftime('%Y%m%d_%H%M%S')}"
        )

    ns = argparse.Namespace(
        input=args.input,
        model=args.model,
        device=args.device,
        compute_type=args.compute_type,
        language=args.language,
        task=args.task,
        beam_size=args.beam_size,
        word_timestamps=args.word_timestamps,
        vad_filter=args.vad_filter,
        output_dir=args.output_dir,
        name=args.name,
    )
    return run_transcribe(ns)


# ---------------------------------------------------------------------------
# history / doctor
# ---------------------------------------------------------------------------


def cmd_history(args: argparse.Namespace) -> int:
    from tts_skill.cli import cmd_history as upstream_history

    ns = argparse.Namespace(type=args.type, show_cmd=args.show_cmd)
    return upstream_history(ns)


def cmd_doctor(args: argparse.Namespace) -> int:  # noqa: ARG001
    from tts_skill.cli import cmd_doctor as upstream_doctor

    return upstream_doctor(argparse.Namespace())


# ---------------------------------------------------------------------------
# world —— 世界观声线盘点（纯读文件，无需 TTS 环境）
# ---------------------------------------------------------------------------

# 角色材料 content 里表示声线绑定的键（绑定串格式见 references/world-voice.md）
VOICE_KEYS = ("voice", "声线")


def _read_json_file(p: Path) -> dict | None:
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def cmd_world(args: argparse.Namespace) -> int:
    """读 manifest + 全部材料 + 已有语音作品，输出世界观声线盘点。"""
    root = WORKSPACE_ROOT
    manifest = _read_json_file(root / "manifest.json")
    if manifest is None:
        print(f"[错误] 未找到世界观清单（manifest.json）: {root}")
        return 1

    wc = manifest.get("worldConfig", {}) or {}
    report: dict = {
        "workspace": str(root),
        "world": {
            "name": wc.get("worldName") or wc.get("name") or "未命名世界",
            "genre": wc.get("genre"),
            "tone": wc.get("tone"),
            "era": wc.get("era"),
            "seedPrompt": wc.get("seedPrompt"),
            "language": wc.get("language"),
        },
        "characters": [],
        "locations": [],
        "events": [],
        "lore": [],
        "audio_works": [],
        "narrator": None,
    }

    # 读全部材料：人物全信息（content 各键）+ 声线绑定
    for a in manifest.get("atoms", []) or []:
        entry = {
            "id": a.get("id"),
            "name": a.get("name"),
            "description": a.get("description"),
            "facts": {},
            "voice": None,
        }
        data = _read_json_file(root / (a.get("path") or ""))
        if data is None:
            entry["facts"]["__error__"] = f"材料读取失败: {a.get('path')}"
        else:
            for kv in data.get("content", []) or []:
                key = kv.get("key", "")
                entry["facts"][key] = kv.get("value", "")
                if key in VOICE_KEYS:
                    entry["voice"] = kv.get("value")
        atype = a.get("type")
        if atype == "character":
            report["characters"].append(entry)
        elif atype == "location":
            report["locations"].append(entry)
        elif atype == "event":
            report["events"].append(entry)
        else:
            report["lore"].append(entry)

    # 已有语音作品 + 旁白档案
    if AUDIO_ROOT.is_dir():
        for d in sorted(p for p in AUDIO_ROOT.iterdir() if p.is_dir()):
            if d.name == "narrator":
                report["narrator"] = _read_json_file(d / "binding.json")
                continue
            t = _read_json_file(d / "tracks.json")
            if t is None:
                continue
            report["audio_works"].append(
                {
                    "slug": d.name,
                    "title": t.get("title"),
                    "mode": t.get("mode"),
                    "engine": t.get("engine") or "omnivoice",
                    "instruct": t.get("instruct"),
                    "seed": t.get("seed"),
                    "text": t.get("text"),
                    "command": t.get("command"),
                }
            )

    # 把作品匹配到角色（标题含角色名 → 视为该角色声线作品），标注绑定状态
    for w in report["audio_works"]:
        title = w.get("title") or ""
        hit = next(
            (c for c in report["characters"] if c["name"] and c["name"] in title),
            None,
        )
        w["character"] = hit["name"] if hit else None
        w["bound"] = bool(hit and hit.get("voice"))
        w["suggest_bind"] = bool(hit and not hit.get("voice"))

    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0

    # 可读报告
    w = report["world"]
    print("=" * 64)
    print(f"世界观：{w['name']}   [genre={w['genre']} tone={w['tone']} era={w['era']}]")
    if w.get("seedPrompt"):
        print(f"开场种子：{w['seedPrompt']}")
    print("=" * 64)

    def _dump(kind: str, entries: list) -> None:
        print(f"\n【{kind}】({len(entries)})")
        for e in entries:
            print(f"· {e['name']} — {e.get('description') or ''}")
            if e.get("voice"):
                print(f"    声线（已绑定）: {e['voice']}")
            for k, v in e.get("facts", {}).items():
                if k in VOICE_KEYS:
                    continue
                if k == "__error__":
                    print(f"    （{v}）")
                    continue
                print(f"    {k}: {v}")

    _dump("角色", report["characters"])
    _dump("地点", report["locations"])
    _dump("事件", report["events"])
    _dump("传说/其他", report["lore"])

    print(f"\n【已有语音作品】({len(report['audio_works'])})")
    for w in report["audio_works"]:
        who = f"→ {w['character']}" if w.get("character") else "→ （未匹配到角色）"
        tag = " [已绑定]" if w.get("bound") else (" [待绑定]" if w.get("suggest_bind") else "")
        print(f"· {w['slug']} — {w['title']}{tag} {who}")
        print(
            f"    engine={w['engine']} mode={w['mode']} seed={w['seed']}"
            + (f" instruct={w['instruct']}" if w.get("instruct") else "")
        )

    if report.get("narrator"):
        print(f"\n【旁白声线档案】已建档: {json.dumps(report['narrator'], ensure_ascii=False)}")
    else:
        print("\n【旁白声线档案】未建档")
    print()
    print("提示：给角色配声线后，把 engine/mode/instruct/ref_audio/seed 写回角色材料")
    print("（content 键 `声线`），下次生成即自动复用；详见 references/world-voice.md")
    return 0


# ---------------------------------------------------------------------------
# bind —— 把角色声线写回材料（content 键 `声线`），供后续生成自动复用
# ---------------------------------------------------------------------------

BINDING_KEY = "声线"
NETA_CLI = os.environ.get("NETA_CLI", "/mods/neta/neta")


def _binding_string(
    engine: str, mode: str, instruct: str | None, seed: int | None, ref_audio: str | None
) -> str:
    parts = [f"engine={engine}", f"mode={mode}"]
    if ref_audio:
        parts.append(f'ref_audio="{ref_audio}"')
    if instruct:
        parts.append(f'instruct="{instruct}"')
    if seed is not None:
        parts.append(f"seed={seed}")
    return "; ".join(parts)


def _find_character_atom(manifest: dict, name: str | None = None, atom_id: str | None = None) -> dict | None:
    atoms = manifest.get("atoms", []) or []
    if atom_id:
        return next((a for a in atoms if a.get("id") == atom_id), None)
    if name:
        chars = [a for a in atoms if a.get("type") == "character"]
        exact = next((a for a in chars if a.get("name") == name), None)
        if exact:
            return exact
        return next((a for a in chars if name in (a.get("name") or "")), None)
    return None


def cmd_bind(args: argparse.Namespace) -> int:
    """把声线绑定写回角色材料 content 键 `声线`（经 neta atom update，按 key 合并）。"""
    root = WORKSPACE_ROOT
    manifest = _read_json_file(root / "manifest.json")
    if manifest is None:
        print(f"[错误] 未找到世界观清单（manifest.json）: {root}")
        return 1

    # 1) 绑定参数：优先从已有语音作品读取（--slug），显式参数覆盖/直接指定
    params: dict = {}
    if args.slug:
        t = _read_json_file(AUDIO_ROOT / args.slug / "tracks.json")
        if t is None:
            print(f"[错误] 未找到语音作品: works/audio/{args.slug}/tracks.json")
            return 1
        params["engine"] = t.get("engine") or "omnivoice"
        params["mode"] = t.get("mode") or "design"
        if t.get("instruct"):
            params["instruct"] = t.get("instruct")
        if t.get("seed") is not None:
            params["seed"] = t.get("seed")
    if args.engine:
        params["engine"] = args.engine
    if args.mode:
        params["mode"] = args.mode
    if args.instruct is not None:
        params["instruct"] = args.instruct
    if args.ref_audio:
        params["ref_audio"] = args.ref_audio
    if args.seed is not None:
        params["seed"] = args.seed

    missing = [k for k in ("engine", "mode") if k not in params]
    if missing:
        print(f"[错误] 缺少必要参数: {', '.join(missing)}（用 --slug 从已有作品读取，或显式传 --engine/--mode）")
        return 1

    # 2) 定位角色
    if not args.character and not args.atom:
        chars = [a.get("name") for a in manifest.get("atoms", []) if a.get("type") == "character"]
        print(f"[错误] 请指定 --character <角色名> 或 --atom <材料id>")
        if chars:
            print(f"可用角色: {', '.join(chars)}")
        return 1
    atom = _find_character_atom(manifest, name=args.character, atom_id=args.atom)
    if atom is None:
        chars = [a.get("name") for a in manifest.get("atoms", []) if a.get("type") == "character"]
        print(f"[错误] 未找到角色: {args.character or args.atom}")
        if chars:
            print(f"可用角色: {', '.join(chars)}")
        return 1

    binding = _binding_string(
        params.get("engine"), params.get("mode"), params.get("instruct"), params.get("seed"), params.get("ref_audio")
    )
    print(f"角色: {atom['name']}（{atom['id']}）")
    print(f"绑定串: {binding}")
    if args.dry_run:
        print("[dry-run] 未写入。以上即将要写入材料 content 键 `声线` 的内容（按 key 合并，不动其他键）。")
        return 0

    # 3) 经 neta atom update 写回（content 按 key 合并，仅新增/更新 `声线`）
    patch = json.dumps(
        {"id": atom["id"], "content": [{"key": BINDING_KEY, "value": binding}]},
        ensure_ascii=False,
    )
    r = subprocess.run(
        [NETA_CLI, "atom", "update"],
        input=patch + "\n",
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    out = (r.stdout or "").strip()
    if r.stderr:
        out += "\n" + r.stderr.strip()
    print(out)
    if r.returncode != 0 or '"ok":false' in out:
        print("[错误] 写回失败，请检查 neta CLI 输出后重试。")
        return 1

    # 4) 验证落盘
    g = subprocess.run(
        [NETA_CLI, "atom", "get", atom["id"]],
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    if g.returncode == 0:
        try:
            data = json.loads(g.stdout)
            for kv in data.get("content", []) or []:
                if kv.get("key") == BINDING_KEY:
                    ok = "✓" if kv.get("value") == binding else "✗ 内容不一致"
                    print(f"验证: content[{BINDING_KEY}] {ok}")
                    break
            else:
                print(f"[警告] 验证未找到 content 键 `{BINDING_KEY}`，请用 `neta atom get` 检查。")
        except Exception:  # noqa: BLE001
            print("[警告] 验证输出无法解析，请用 `neta atom get` 检查。")
    print("下次给该角色配声线时按此绑定复用（engine+mode+seed 一致即同一把声音）。")
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="studio_tts",
        description="Studio TTS — OmniVoice 语音生成 / 转写（Studio 适配版）",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command")

    p_setup = sub.add_parser("setup", help="安装环境（首次运行必需）")
    p_setup.add_argument("--with_asr", action="store_true", help="同时安装语音转文字依赖")
    p_setup.add_argument("--force", action="store_true", help="强制重新安装")
    p_setup.set_defaults(func=cmd_setup)

    p_voice = sub.add_parser("voice", help="生成语音 → works/audio/<slug>/（含播放页）")
    p_voice.add_argument("--text", required=True, help="要合成的文本")
    p_voice.add_argument("--mode", choices=["clone", "design", "auto"], default="auto")
    p_voice.add_argument("--ref_audio", default=None, help="参考音频（clone 模式）")
    p_voice.add_argument("--ref_text", default=None, help="参考音频文本（clone，留空自动转写）")
    p_voice.add_argument("--instruct", default=None, help="声音属性（design，如 'male, british accent'）")
    p_voice.add_argument("--language", default=None, help="语种（如 Chinese / en）")
    p_voice.add_argument("--seed", type=int, default=None, help="随机种子（相同种子可复现）")
    p_voice.add_argument("--batch_count", type=int, default=1, help="批量生成数量（默认 1）")
    p_voice.add_argument("--num_step", type=int, default=32)
    p_voice.add_argument("--speed", type=float, default=1.0)
    p_voice.add_argument("--duration", type=float, default=None)
    p_voice.add_argument("--guidance_scale", type=float, default=2.0)
    p_voice.add_argument("--t_shift", type=float, default=0.1)
    p_voice.add_argument("--denoise", type=lambda v: v.lower() in ("true", "1", "yes"), default=True)
    p_voice.add_argument("--postprocess_output", type=lambda v: v.lower() in ("true", "1", "yes"), default=True)
    p_voice.add_argument("--normalize_text", type=lambda v: v.lower() in ("true", "1", "yes"), default=False)
    p_voice.add_argument("--model", default=None, help=f"引擎 ID（默认 {DEFAULT_ENGINE}；可用 models 查看全部）；对 omnivoice 也可传 HF 仓库名覆盖模型")
    p_voice.add_argument("--device", default=None, help="推理设备（自动检测）")
    p_voice.add_argument("--slug", default=None, help="作品目录名（默认 voice_<时间戳>）")
    p_voice.add_argument("--title", default=None, help="作品标题（默认取记录名）")
    p_voice.add_argument("--desc", default=None, help="作品描述")
    p_voice.add_argument("--name", default=None, help="历史记录名称")
    p_voice.set_defaults(func=cmd_voice)

    p_models = sub.add_parser("models", help="模型列表 / 状态 / 安装（多引擎）")
    p_models.add_argument("action", nargs="?", choices=["list", "status", "install"], default="list", help="list=列表, status=安装状态, install=安装")
    p_models.add_argument("model_id", nargs="?", default=None, help="install 时的模型 ID")
    p_models.add_argument("--source", choices=["hf", "modelscope"], default=None, help="权重下载源：hf=HuggingFace（默认）/ modelscope=魔搭；也可用 MODELSCOPE_HUB=1 环境变量")
    p_models.set_defaults(func=cmd_models)

    p_ts = sub.add_parser("transcribe", help="音频/视频转文字")
    p_ts.add_argument("--input", required=True, help="输入音频/视频文件")
    p_ts.add_argument("--model", default="large-v3", help="模型 tiny/base/small/medium/large-v3")
    p_ts.add_argument("--device", default=None, help="cuda/cpu（自动检测）")
    p_ts.add_argument("--compute_type", default=None)
    p_ts.add_argument("--language", default=None, help="语言代码（如 zh/en/ja），留空自动检测")
    p_ts.add_argument("--task", choices=["transcribe", "translate"], default="transcribe")
    p_ts.add_argument("--beam_size", type=int, default=5)
    p_ts.add_argument("--word_timestamps", type=lambda v: v.lower() in ("true", "1", "yes"), default=True)
    p_ts.add_argument("--vad_filter", type=lambda v: v.lower() in ("true", "1", "yes"), default=True)
    p_ts.add_argument("--output_dir", default=None, help="输出目录（默认 works/audio/transcribe_<时间戳>/）")
    p_ts.add_argument("--name", default=None)
    p_ts.set_defaults(func=cmd_transcribe)

    p_h = sub.add_parser("history", help="查看历史记录")
    p_h.add_argument("--type", choices=["tts", "asr", "all"], default="all")
    p_h.add_argument("--show_cmd", action="store_true")
    p_h.set_defaults(func=cmd_history)

    p_d = sub.add_parser("doctor", help="诊断环境")
    p_d.set_defaults(func=cmd_doctor)

    p_world = sub.add_parser("world", help="世界观声线盘点（读 manifest + 材料 + 已有语音作品，无需 TTS 环境）")
    p_world.add_argument("--json", action="store_true", help="输出 JSON 报告（供程序化消费）")
    p_world.set_defaults(func=cmd_world)

    p_bind = sub.add_parser("bind", help="把角色声线写回材料（content 键 `声线`），后续生成自动复用")
    p_bind.add_argument("--slug", default=None, help="从已有语音作品 works/audio/<slug>/tracks.json 读取绑定参数")
    p_bind.add_argument("--character", default=None, help="角色名（按名称匹配材料）")
    p_bind.add_argument("--atom", default=None, help="角色材料 id（与 --character 二选一）")
    p_bind.add_argument("--engine", default=None, help="引擎 ID（覆盖 --slug 读取值 / 直接指定）")
    p_bind.add_argument("--mode", choices=["auto", "design", "clone"], default=None)
    p_bind.add_argument("--instruct", default=None, help="声音属性（design 模式）")
    p_bind.add_argument("--ref_audio", default=None, help="参考音频路径（clone 模式）")
    p_bind.add_argument("--seed", type=int, default=None)
    p_bind.add_argument("--dry-run", action="store_true", help="只显示将写入的内容，不写入")
    p_bind.set_defaults(func=cmd_bind)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        return 0
    if args.command == "world":
        # world 盘点只读文件，无需 TTS 环境，跳过 venv 自举
        return cmd_world(args)
    if args.command == "bind":
        # bind 只读文件 + 调 neta CLI，无需 TTS 环境，跳过 venv 自举
        return cmd_bind(args)
    _bootstrap_venv()
    # 沙箱环境可能注入 PIP_USER=true，会破坏 venv 内的 pip 安装
    os.environ.pop("PIP_USER", None)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print("\n已中断")
        return 130
    except Exception as e:  # noqa: BLE001
        import traceback

        print(f"[错误] {e}")
        if os.environ.get("STUDIO_TTS_DEBUG"):
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
