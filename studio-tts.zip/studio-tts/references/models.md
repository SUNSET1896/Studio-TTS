# 多模型支持 — 模型注册表、下载方法与选型

本技能支持多引擎。用 `voice --model <ID>` 选择，用 `models` 子命令管理：

```bash
python3 studio_tts.py models                # 模型列表
python3 studio_tts.py models status         # 各模型安装状态
python3 studio_tts.py models install <ID>   # 安装某模型（含权重下载）
```

## 模型一览（依据《2026 开源 TTS 选型指南》整理）

| ID | 模型 | 许可证 | 安装方式 | 硬件 | 验证 |
|---|---|---|---|---|---|
| `omnivoice` | OmniVoice | Apache-2.0 | 随 setup 自动装 | CPU/GPU | ✅ 已跑通 |
| `spark-tts` | Spark-TTS 0.5B | Apache-2.0 | `models install spark-tts` | CPU 友好 | ✅ 已跑通 |
| `qwen3-tts` | **Qwen3-TTS 0.6B/1.7B（默认）** | Apache-2.0 | `models install qwen3-tts`（0.6B-CustomVoice 公开，免 token） | GPU 推荐 | ⏳ 待实测 |
| `f5-tts` | F5-TTS 0.3B | MIT | `models install f5-tts` | CPU/GPU | ⏳ 未实测 |
| `cosyvoice2` | CosyVoice 2 0.5B | Apache-2.0 | 权重：魔搭 iic/CosyVoice2-0.5B 匿名可拉；引擎：手动 conda | GPU ~4GB | 文档（权重已验证） |
| `index-tts2` | IndexTTS2 1.5B | Apache-2.0 | 权重：魔搭 IndexTeam/IndexTTS-2 匿名可拉（实测 1.2GB）；引擎：手动 uv | GPU ~8GB | 文档（权重已验证） |
| `fish-speech` | Fish Speech 1.5 | Apache-2.0 | 手动（conda py3.12 独立环境） | GPU ≥4GB | 文档 |

## 各模型下载方法（详细）

### ModelScope（魔搭）下载源 —— 国内首选

魔搭（modelscope.cn，阿里系）是 huggingface.co 之外的独立仓库，**本技能全部模型
在魔搭上都有**（已验证），国内网络下推荐用它：

```bash
# 方式 A：本技能（推荐）
python3 studio_tts.py models install spark-tts --source modelscope
# 或环境变量默认走魔搭：export MODELSCOPE_HUB=1

# 方式 B：modelscope CLI
pip install -U modelscope
modelscope download --model SparkAudio/Spark-TTS-0.5B --local_dir ./Spark-TTS-0.5B
# 或 git：git clone https://www.modelscope.cn/<组织>/<仓库>.git（大文件需 git lfs）
```

魔搭可用仓库（全部已验证存在）：

| 引擎 | 魔搭仓库 | 公开/受限 |
|---|---|---|
| omnivoice | `k2-fsa/OmniVoice` | 公开 ✅ |
| spark-tts | `SparkAudio/Spark-TTS-0.5B` | 公开 ✅ |
| qwen3-tts | `Qwen/Qwen3-TTS-12Hz-0.6B-{CustomVoice,Base}`（另 1.7B 全系）；**0.6B-VoiceDesign 受限** | CustomVoice/Base 公开 ✅（实测 clone 成功），VoiceDesign 受限 ⚠️ |
| f5-tts | `SWivid/F5-TTS` | 公开 ✅ |
| cosyvoice2 | `iic/CosyVoice2-0.5B`（魔搭官方 iic 组织） | **公开 ✅ 实测 clone + LFS 成功**（HF 上 FunAudioLLM/CosyVoice-2-0.5B 仍受限） |
| index-tts2 | `IndexTeam/IndexTTS-2`（带连字符，魔搭官方） | **公开 ✅ 实测 clone + LFS（s2mel.pth 1.2GB）成功**（HF 上 IndexTeam/IndexTTS2 仍受限） |
| fish-speech | `fishaudio/fish-speech-1.5` | 公开 ✅ |
| ASR | `Systran/faster-whisper-large-v3`（及 tiny~medium） | 公开 ✅ |

**注意**：Qwen3-TTS 的 `CustomVoice` / `Base` 变体在魔搭公开可拉（实测 clone 成功）；
仅 `0.6B-VoiceDesign` 受限（与 HF 一致，需登录 modelscope.cn 接受协议 + `MODELSCOPE_API_TOKEN`）。

### 国内网络：hf-mirror 镜像站（CLI 方法）

hf-mirror.com 是 huggingface.co 的国内镜像（公益项目），官方 CLI 用法：

```bash
pip install -U huggingface_hub
export HF_ENDPOINT=https://hf-mirror.com

# 下载模型（示例：Qwen3-TTS VoiceDesign 变体）
hf download Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice --local-dir ./Qwen3-TTS-0.6B-CustomVoice
# 或旧版命令：huggingface-cli download --resume-download <repo> --local-dir <dir>
```

本技能尊重该环境变量：设了 `HF_ENDPOINT` 就按镜像下载，没设则直连官方源。
**注意**：镜像只加速公开仓库；受限仓库（如 Qwen3-TTS）仍需登录接受许可并提供
`HF_TOKEN`，镜像不会绕过授权；当前唯一受限的是 Qwen `0.6B-VoiceDesign`（已弃用）。海外/直连环境（如本沙箱）镜像会 308 重定向回源站，
直连反而更快。
国内更推荐 **ModelScope（魔搭）**：它是独立仓库（非重定向），全部模型都有，
见上文「ModelScope 下载源」；`models install <ID> --source modelscope` 一键走魔搭。

### qwen3-tts（当前默认引擎）
```bash
python3 studio_tts.py models install qwen3-tts
```
- 环境（`.venv-qwen`）已装好；**权重公开可拉（免 token）**，首次生成自动下载：
  - design → `Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice`（HF ✅ / 魔搭 ✅ 均可匿名拉取；
    CustomVoice 模型用内置 speaker + 自然语言语气实现音色设计）
  - clone → `Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice`
  - auto → `Qwen/Qwen3-TTS-12Hz-0.6B-Base`
- **注意**：`0.6B-VoiceDesign` 变体在 HF/魔搭均受限（需 token），已被默认映射替换掉。
- `voice` 不带 `--model` 时即用本引擎。

### omnivoice（原默认，CPU 直接可跑）
```bash
python3 studio_tts.py setup
```
- 权重：`k2-fsa/OmniVoice`（HuggingFace，~5GB，自动下载到 `~/.cache/huggingface`，所有世界共用）
- 三模式：clone（参考音频复刻）/ design（属性设计）/ auto
- 想切回：`voice --model omnivoice ...`

### spark-tts（CPU 最友好，已验证）
```bash
python3 studio_tts.py models install spark-tts
```
实际执行：
1. 创建 `.venv-spark`，装 torch CPU + `einops einx omegaconf safetensors soxr tqdm soundfile numpy transformers==4.46.2`
2. `git clone --depth 1 https://github.com/SparkAudio/Spark-TTS.git` → `scripts/models/Spark-TTS-src`
3. `snapshot_download("SparkAudio/Spark-TTS-0.5B")` → `scripts/models/weights/Spark-TTS-0.5B`（~3.7GB，含 BiCodec + LLM + wav2vec2）

调用：`voice --model spark-tts --mode design --instruct "male, low pitch"`（design 支持性别/音调/语速；clone 需参考音频）。
注意：`process_prompt_control` 要求三项属性齐全，缺失自动补默认值（male/moderate/moderate）。

### qwen3-tts（低延迟 / 音色设计，默认引擎）
```bash
python3 studio_tts.py models install qwen3-tts
```
实际执行：
1. 创建 `.venv-qwen`，装 torch CPU + `qwen-tts`（PyPI，0.1.1）
2. **权重公开免 token**，首次生成自动下载：
   - design → `Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice`（HF/魔搭匿名可拉；用内置 speaker + 自然语言语气实现音色设计）
   - clone → `Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice`
   - auto → `Qwen/Qwen3-TTS-12Hz-0.6B-Base`
   - （`0.6B-VoiceDesign` 变体在 HF/魔搭均受限需 token，已弃用）

调用：`voice --model qwen3-tts --mode design --instruct "亲切温柔的女声"`。
注意：文章作者实测不能加减速；`sox` 未安装时只打印警告，不影响设计模式。

### f5-tts（纯零样本克隆，MIT）
```bash
python3 studio_tts.py models install f5-tts
```
1. 创建 `.venv-f5`，装 torch CPU + `f5-tts`（PyPI，1.1.22）
2. 首次生成自动下载 `SWivid/F5-TTS`（~1.4GB）

调用：`voice --model f5-tts --mode clone --ref_audio ref.wav --ref_text "参考文本"`。
注意：F5 是纯克隆模型，无 design/auto 模式，必须给参考音频。

### cosyvoice2（文章首选，工程成熟度最高）
```bash
git clone --recursive https://github.com/FunAudioLLM/CosyVoice.git
cd CosyVoice
conda create -n cosyvoice python=3.10 && conda activate cosyvoice
pip install -r requirements.txt
# pynini 装不上时：
conda install -y -c conda-forge pynini==2.1.5
```
- 权重：魔搭 `iic/CosyVoice2-0.5B`（~2GB，实测 clone + LFS 匿名可拉；HF 上 FunAudioLLM/CosyVoice-2-0.5B 受限）
- 需要独立 conda 环境（本技能 venv 不兼容）；GPU ~4GB 显存

### index-tts2（情感/时长控制天花板）
```bash
git clone https://github.com/IndexTeam/IndexTTS.git
cd IndexTTS
uv run webui.py     # 依赖用 uv 管理，不支持 pip/conda 直接装
```
- 权重：魔搭 `IndexTeam/IndexTTS-2`（~3GB，实测 clone + LFS 匿名可拉；HF 上受限）；GPU FP16 ~7.8GB 显存
- 7 种情感（happy/angry/sad/...）+ Token 级时长控制

### fish-speech（多语言全能）
```bash
conda create -n fish-speech python=3.12.10 && conda activate fish-speech
pip install torch==2.8.0 torchaudio==2.8.0 --index-url https://download.pytorch.org/whl/cu126
git clone https://github.com/fishaudio/fish-speech && cd fish-speech
git checkout v1.5.1 && pip install -e .
```
- 权重：`fishaudio/fish-speech-1.5`（~1GB）；GPU ≥4GB（克隆 ≥6GB）
- 必须 Python 3.12（3.13/3.14 依赖冲突）；模型权重建议 ModelScope 下载

## 引擎对比速查

| 能力 | omnivoice | spark-tts | qwen3-tts | f5-tts | cosyvoice2 | index-tts2 | fish-speech |
|---|---|---|---|---|---|---|---|
| design 属性设计 | ✅ 全属性 | 性别/音调/语速 | ✅ 自然语言 | ❌ | ✅ NLC | ❌ | 部分 |
| 零样本克隆 | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| 情感控制 | ❌ | ❌ | 部分 | 部分 | ✅ | ✅ 7种 | ✅ |
| 方言 | ✅ 中文方言 | ❌ | ❌ | ❌ | ✅ 粤/川等 | ❌ | ❌ |
| CPU 可跑 | ✅ 慢 | ✅ 较快 | 慢 | 慢 | ❌ | ❌ | ❌ |
| 独立环境 | 内置 | 独立 venv | 独立 venv | 独立 venv | conda | uv | conda 3.12 |

## 可复现性说明

- 所有引擎都接受 `--seed`；相同种子 + 相同参数尽量可复现（不同引擎的采样器不同，效果会有差异）。
- `tracks.json` 和播放页的可复现命令都带 `--model <ID>`，换引擎重跑只需改 ID。
- 换设备（cuda↔cpu）结果可能不同；外部引擎以各自 venv 的 torch 为准。
