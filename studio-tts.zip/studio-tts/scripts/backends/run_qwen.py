#!/usr/bin/env python3
"""Qwen3-TTS 后端 runner。由 .venv-qwen/bin/python 执行。

用法: python run_qwen.py <args.json> <output.wav>

args.json 字段:
  text       必填
  mode       auto / design / clone
  instruct   声音属性自然语言描述（design）
  ref_audio  参考音频（clone）
  ref_text   参考音频文本（clone）
  language   语言（如 Chinese）
  seed       随机种子
  device     cpu / cuda
  model_id   模型仓库（默认 VoiceDesign 0.6B）

注意：Qwen 模型在 HF 上是受限仓库，需要 HF_TOKEN 且已在模型页接受许可。
"""

from __future__ import annotations

import json
import sys

import numpy as np
import soundfile as sf
import torch

DEFAULT_MODEL = "Qwen/Qwen3-TTS-12Hz-0.6B-VoiceDesign"


def main() -> int:
    args = json.load(open(sys.argv[1], encoding="utf-8"))
    out_path = sys.argv[2]
    model_id = args.get("model_id") or DEFAULT_MODEL
    device = args.get("device") or ("cuda" if torch.cuda.is_available() else "cpu")
    dtype = torch.bfloat16 if device == "cuda" else torch.float32
    if args.get("seed") is not None:
        torch.manual_seed(int(args["seed"]))
        np.random.seed(int(args["seed"]))

    from qwen_tts import Qwen3TTSModel

    device_map = device if device == "cpu" else "cuda:0"
    model = Qwen3TTSModel.from_pretrained(model_id, device_map=device_map, dtype=dtype)
    mode = args.get("mode", "auto")
    is_custom_voice = "CustomVoice" in model_id

    def _default_speaker():
        speakers = model.get_supported_speakers() or []
        return speakers[0] if speakers else "Claribel"

    try:
        if mode == "clone" and args.get("ref_audio"):
            wavs, sr = model.generate_voice_clone(
                text=args["text"],
                language=args.get("language"),
                ref_audio=args["ref_audio"],
                ref_text=args.get("ref_text"),
            )
        elif mode == "design" and args.get("instruct"):
            if is_custom_voice:
                # CustomVoice 模型用内置 speaker + 自然语言语气实现音色设计
                wavs, sr = model.generate_custom_voice(
                    text=args["text"],
                    speaker=_default_speaker(),
                    language=args.get("language"),
                    instruct=args["instruct"],
                )
            else:
                wavs, sr = model.generate_voice_design(
                    text=args["text"],
                    instruct=args["instruct"],
                    language=args.get("language"),
                )
        else:
            if is_custom_voice:
                wavs, sr = model.generate_custom_voice(
                    text=args["text"],
                    speaker=_default_speaker(),
                    language=args.get("language"),
                    instruct=args.get("instruct") or "natural, clear, friendly",
                )
            else:
                wavs, sr = model.generate_voice_design(
                    text=args["text"],
                    instruct=args.get("instruct") or "natural, clear, friendly",
                    language=args.get("language"),
                )
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"{type(e).__name__}: {e}"}))
        return 1

    audio = np.asarray(wavs[0]).squeeze()
    sf.write(out_path, audio, sr)
    print(json.dumps({"ok": True, "sr": sr, "duration": round(len(audio) / sr, 3)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
