# Studio TTS · 技能包

一个 Studio 适配的文本转语音 / 声音克隆 / 语音转文字技能发布包，格式遵循
agentskills.io 规范（技能目录内含 `SKILL.md` 与可选资源），在支持 skills 的环境
（Neta Studio / Codex / 其他 agentskills 兼容宿主）中均可安装。

原型：https://github.com/boommanpro/tts-skill（MIT，基于 OmniVoice + faster-whisper）。
本包是它的 Studio 适配版：保留 CLI 生成/转写核心，去掉 Web 服务与前端；**多引擎
可切换**（Qwen3-TTS 默认 / OmniVoice / Spark-TTS / F5-TTS / CosyVoice 2 /
IndexTTS2 / Fish Speech），每个引擎独立 venv，互不污染；产出 `works/audio/<slug>/`
语音作品（wav + mp3 + 播放页 + tracks.json），可发布为 Studio Work。

## 包含内容

| 技能 | 作用 | 资源 |
|---|---|---|
| `studio-tts` | 文本转语音（auto 自动 / design 声音设计 / clone 声音克隆）；音频/视频转文字（词级时间戳）；随机种子可复现；**多模型可选**（`voice --model <ID>`，`models install <ID>` 下载权重）；**世界观适配**（`world` 子命令盘点 + 读世界→理故事→询问→生成→回写工作流） | `references/params.md`（参数表）、`references/voice-design.md`（声音属性）、`references/models.md`（多引擎下载方法与选型）、`references/studio-integration.md`（发布/交付/错误处理）、`references/world-voice.md`（世界观适配工作流）、`scripts/`（studio_tts.py + backends/ 外部引擎 runner + `requirements*.txt` 依赖清单 + vendored tts_skill 包 + Spark-TTS 源码） |

## 安装方法

### 方式一：复制到技能目录（推荐）

```bash
# REPO 作用域（项目/世界内，团队共享）
cp -r studio-tts /workspace/.agents/skills/

# USER 作用域（个人跨项目通用）
cp -r studio-tts ~/.agents/skills/

# ADMIN 作用域（机器级，需权限）
cp -r studio-tts /etc/codex/skills/
```

### 方式二：解压 zip

```bash
unzip studio-tts-package.zip -d /workspace/.agents/skills/
```

## 使用

安装后重启 / 重载宿主，技能按需自动触发。首次使用：

```bash
# 0. 读世界（世界观适配，无需 TTS 环境）：角色/地点/事件/已有声线盘点
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py world

# 1. 初始化主环境（OmniVoice + ASR + 魔搭 SDK，约 10–20 分钟）
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py setup --with_asr

# 2. 查看/安装引擎（默认引擎 qwen3-tts 全部公开变体，免 token）
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py models

# 3. 生成语音（不传 --model 即用默认引擎 qwen3-tts）
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py voice \
  --text "你好，欢迎。" --mode design --instruct "亲切温柔的女声" --seed 1 --slug hello

# 想用 CPU 直接可跑的引擎：voice --model omnivoice / --model spark-tts

# 4. 把声线写回角色材料（下次自动复用同一把声音；--dry-run 先预览）
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py bind \
  --slug <slug> --character <角色名>
```

转写素材：

```bash
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py transcribe --input meeting.mp4 --language zh
```

语音产出落成 `works/audio/<slug>/`（wav + mp3 + 播放页 + tracks.json），由执行
agent 走 `neta work init web` + `neta work publish web` 发布为 Studio Work。

## 默认引擎：qwen3-tts（免 token）

本包默认引擎是 Qwen3-TTS。权重**公开可拉，无需登录**：

- design → `Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice`（HF / 魔搭均可匿名拉取；
  用内置 speaker + 自然语言语气实现音色设计）
- clone → `Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice`
- auto → `Qwen/Qwen3-TTS-12Hz-0.6B-Base`

`models install qwen3-tts` 一键装环境；首次 `voice` 自动下载对应变体权重
（~1.5GB/个）。
**注意**：`Qwen/Qwen3-TTS-12Hz-0.6B-VoiceDesign` 变体在 HF 与魔搭均受限
（需登录接受许可 + token），已从默认映射中移除；若坚持用它，需 `HF_TOKEN`
或 `MODELSCOPE_API_TOKEN`。

## 模型下载权限速查（2026-08 实测）

**全部 7 个引擎的权重均可匿名下载**，没有一个需要登录：

| 模型 | 权重下载 | 说明 |
|---|---|---|
| OmniVoice | ✅ 公开 | HF + 魔搭均可 |
| Spark-TTS | ✅ 公开 | HF + 魔搭均可（实测下载） |
| Qwen3-TTS（默认变体） | ✅ 公开 | CustomVoice / Base 全系，HF + 魔搭均可 |
| F5-TTS | ✅ 公开 | HF |
| Fish Speech 1.5 | ✅ 公开 | HF；引擎需手动 conda 3.12 |
| CosyVoice 2 | ✅ 公开（魔搭 `iic/CosyVoice2-0.5B`） | 实测 clone + LFS 成功；HF 上仍受限；引擎需手动 conda |
| IndexTTS2 | ✅ 公开（魔搭 `IndexTeam/IndexTTS-2`） | 实测 clone + LFS（1.2GB）成功；HF 上仍受限；引擎需手动 uv |
| faster-whisper（ASR） | ✅ 公开 | HF + 魔搭 |

> 下载能解锁 ≠ 引擎能跑：CosyVoice 2 / IndexTTS2 / Fish Speech 的权重都公开了，
> 但运行环境仍需手动搭（conda/uv 独立环境 + GPU）；CPU 沙箱内可直接跑的是
> OmniVoice、Spark-TTS、Qwen3-TTS。

## 国内网络：ModelScope（魔搭）下载源 —— 推荐

魔搭（modelscope.cn，阿里系）是 huggingface.co 之外的独立仓库：

```bash
python3 studio_tts.py models install spark-tts --source modelscope   # 一键走魔搭
# 或环境变量默认：export MODELSCOPE_HUB=1
# 或 CLI：pip install -U modelscope && modelscope download --model <repo> --local_dir <dir>
```

魔搭可用仓库（全部实测）：`k2-fsa/OmniVoice`、`SparkAudio/Spark-TTS-0.5B`、
`Qwen/Qwen3-TTS-12Hz-0.6B-{CustomVoice,Base}`、**`iic/CosyVoice2-0.5B`**、
**`IndexTeam/IndexTTS-2`**、`SWivid/F5-TTS`、`fishaudio/fish-speech-1.5`、
`Systran/faster-whisper-large-v3`（ASR）。

## 国内网络：hf-mirror 镜像站（CLI 方法）

hf-mirror.com 是 huggingface.co 的国内公益镜像，官方 CLI 用法：

```bash
pip install -U huggingface_hub
export HF_ENDPOINT=https://hf-mirror.com
hf download Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice --local-dir ./CustomVoice
# 旧版命令：huggingface-cli download --resume-download <repo> --local-dir <dir>
```

本技能尊重 `HF_ENDPOINT` 环境变量（用户设置了就按镜像走，没设则直连官方源）。
注意：镜像只加速公开仓库，受限仓库仍需 token（当前唯一受限的是 Qwen
`0.6B-VoiceDesign`，已弃用）。海外/直连环境（如阿里云美西沙箱）镜像会把流量
308 重定向回源站，直连反而更快。

## 依赖清单（requirements）

每个环境的依赖都有独立清单，`models install` 按文件安装：

| 文件 | 对应环境 | 内容 |
|---|---|---|
| `scripts/requirements.txt` | 主环境 `.venv`（OmniVoice + ASR + 魔搭 SDK） | omnivoice / soundfile / numpy / **transformers>=5.16（锁）** / **modelscope** / faster-whisper / imageio-ffmpeg / num2words |
| `scripts/requirements-spark.txt` | `.venv-spark` | einops / einx / omegaconf / safetensors / soxr / transformers==4.46.2 等 |
| `scripts/requirements-qwen.txt` | `.venv-qwen` | qwen-tts==0.1.1 / transformers==4.57.3 / accelerate==1.12.0 / librosa 等 |
| `scripts/requirements-f5.txt` | `.venv-f5` | f5-tts |

torch / torchaudio 由安装流程按平台单独安装（本沙箱为 CPU 索引 2.8.0+cpu），
不写在 requirements 内（避免 CUDA/CPU 冲突）。

## 多引擎说明

- 默认引擎 **`qwen3-tts`**（免 token）；`omnivoice` 随 setup 安装（CPU 直接可跑，
  想切回用 `voice --model omnivoice`）；`spark-tts` 已验证可跑（CPU 友好）；
  `f5-tts` pip 可装；`cosyvoice2`（权重魔搭公开可拉，引擎需 conda 独立环境）/
  `index-tts2`（权重魔搭公开可拉，引擎需 uv）/ `fish-speech`（权重公开，引擎需
  conda 3.12），`models install` 会打印精确手动步骤。
- 每个引擎独立 venv（`.venv-spark` / `.venv-qwen` / `.venv-f5`），避免依赖冲突
  （如 qwen-tts 会降级 transformers 破坏 omnivoice；主环境已锁 transformers>=5.16）。
- 权重下载源三选一：HuggingFace 直连（默认）/ ModelScope 魔搭（`--source
  modelscope` 或 `MODELSCOPE_HUB=1`）/ hf-mirror 镜像（`HF_ENDPOINT`）。
- 选型依据《2026 开源 TTS 选型指南》：中文首选 CosyVoice 2、低延迟 Qwen3-TTS、
  情感控制 IndexTTS2、无 GPU 用 Spark-TTS。
- 权重不打包（数百 MB 到数 GB），由 `models install` 按需下载；模型缓存
  （HF 默认 `~/.cache/huggingface`，魔搭默认 `~/.cache/modelscope`）所有世界共用。

## 说明

- 技能文件内不含任何具体产品/世界观内容，全部参数化——文本、声音属性、参考音频
  由调用方传入，换任何角色/语言/素材均可复用。
- 适配时修复的上游问题（均以注释留在 vendored 代码中）：pip 镜像 `--index-url`
  与 `-i` 冲突、PEP 668 环境隔离、`PIP_USER` 注入、CPU 上 float16 不可用、
  hf-mirror 重定向导致的模型下载失败（改为真实网络探测 + 尊重用户 HF_ENDPOINT）、
  可复现命令改为 Studio 原生 `studio_tts.py voice` 形式。
- 升级记录：
  - v2.11：部署修复包。①外部引擎安装（`models install`）新增「升级 pip」步骤——旧版 ensurepip pip 23.x 在注入 `PIP_USER=true` 的环境里报 `--user` 错、在专用 `--index-url` 下无法解析构建依赖（flit_core）；②安装/下载改为实时流式输出（此前 capture_output 吞掉全部输出、结束才打印，日志长时间为空无法区分下载中/卡死）；③修复流式输出引入的返回码回归（裸 rc int vs 布尔）；④`models install qwen3-tts` 权重提示更新为公开变体免 token（v2.5 起 CustomVoice/Base 已公开，旧文案仍要求 HF_TOKEN）；⑤`world` 命令世界名兼容 `worldConfig.name`；⑥`models status` 就绪判定改为真实环境状态（omnivoice 查 setup 标记；列名「验证」→「就绪」，list 的「验证」→「可用」并注明含义）；⑦文档错误表补「安装僵死→kill 重试（部分下载已入缓存）」条目。
  - v2.10：`bind` 子命令。把角色声线写回材料 `content` 键 `声线`（从 `--slug` 作品
    读参数或显式指定；经 `neta atom update` 按 key 合并，不动其他键；`--dry-run`
    预览；无需 TTS 环境）。
  - v2.9：世界观适配。新增 `world` 子命令（世界观声线盘点：读 manifest + 全部材料 +
    已有语音作品，无需 TTS 环境，纯读文件）；SKILL.md 新增「世界观适配工作流」为默认
    入口（读世界 → 理故事 → 盘点声线 → 询问 → 生成 → 回写）；新增
    `references/world-voice.md`；技能保持世界观无关，文档示例全部通用化（不含任何
    世界具体内容）。
  - v1：首个 Studio 适配版。四条命令（setup/voice/transcribe/history/doctor），
    venv 自举，语音作品发布管线，用真实目标（世界角色台词）跑通验证。
  - v2：多引擎支持。模型注册表 + `models` 子命令（list/status/install），
    `voice --model <ID>` 分发；Spark-TTS 已实测跑通（公路旅人台词）；
    Qwen3-TTS / F5-TTS 后端 runner 就绪（待权重授权/实测）；
    CosyVoice 2 / IndexTTS2 / Fish Speech 文档化手动安装。
  - v2.1：依赖清单文件化。`scripts/requirements*.txt` 成为各引擎依赖的规范清单
    （主环境 / spark / qwen / f5），`models install` 按文件安装（缺失时回退
    注册表内嵌列表）；重新打包发布。
  - v2.2：默认引擎切换为 `qwen3-tts`；可复现命令始终显式携带 `--model <ID>`；
    文档同步。
  - v2.3：镜像站支持。尊重 `HF_ENDPOINT`（国内用户可 `export
    HF_ENDPOINT=https://hf-mirror.com` 用镜像 CLI 下载）；`models install
    qwen3-tts` 检测到 HF_TOKEN 时自动下载三个变体权重；实测确认镜像不绕过
    受限仓库授权。
  - v2.4：ModelScope（魔搭）下载源。`models install <ID> --source modelscope`
    （或 `MODELSCOPE_HUB=1`）；注册表全部模型补充魔搭仓库；实测 SDK 下载管线可用。
  - v2.5：Qwen 变体替换。design 模式从受限的 `0.6B-VoiceDesign` 换成公开的
    `0.6B-CustomVoice`（HF / 魔搭均可匿名拉取，实测验证）；runner 在
    CustomVoice 模型上用 speaker + instruct 实现音色设计；Qwen 默认全部免 token。
  - v2.6：CosyVoice 2 权重解锁。魔搭官方 `iic/CosyVoice2-0.5B` 实测 clone + LFS
    匿名可拉（此前测的 FunAudioLLM/CosyVoice-2-0.5B 为错误仓库，HF 上仍受限）；
    注册表与文档同步。
  - v2.7：IndexTTS2 权重解锁。魔搭官方 `IndexTeam/IndexTTS-2`（带连字符）实测
    clone + LFS（s2mel.pth 1.2GB）匿名可拉；至此全部引擎权重均可匿名下载。
  - v2.8：收口更新。全部文档清除过时表述（Qwen 免 token、CosyVoice2/IndexTTS2
    魔搭仓库修正）；requirements.txt 补 modelscope + transformers>=5.16 兼容锁；
    setup_env CORE_DEPENDENCIES 同步补 modelscope。
