# 参数参考 — studio_tts voice / transcribe

> 运行时：`python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py <子命令>`

## voice —— 生成语音

| 参数 | 说明 | 默认 |
|---|---|---|
| `--text` | 要合成的文本（**必填**） | - |
| `--mode` | `auto` 自动 / `design` 声音设计 / `clone` 声音克隆 | auto |
| `--ref_audio` | 参考音频路径（clone 模式必填） | - |
| `--ref_text` | 参考音频的文本（clone，留空自动转写） | - |
| `--instruct` | 声音属性描述（design 模式，如 `"male, middle-aged, low pitch"`） | - |
| `--language` | 语种（如 `Chinese`、`en`），留空自动检测 | 自动 |
| `--seed` | 随机种子；相同种子 + 相同参数 = 相同音频 | 随机 |
| `--batch_count` | 批量数量（1–5，每个用不同种子） | 1 |
| `--num_step` | 扩散解码步数（更小更快） | 32 |
| `--speed` | 语速（>1 更快） | 1.0 |
| `--duration` | 固定时长（秒），设置后覆盖 speed | - |
| `--guidance_scale` | 引导尺度 | 2.0 |
| `--t_shift` | 时间步偏移 | 0.1 |
| `--denoise` | 降噪 token | true |
| `--postprocess_output` | 输出后处理 | true |
| `--normalize_text` | 文本归一化（数字/符号朗读） | false |
| `--model` | 引擎 ID：`qwen3-tts`(默认)/`omnivoice`/`spark-tts`/`f5-tts`/`cosyvoice2`/`index-tts2`/`fish-speech`；对 omnivoice 也可传 HF 仓库名 | qwen3-tts |
| `--device` | 推理设备（cuda/mps/xpu/cpu，自动检测） | 自动 |
| `--slug` | 作品目录名 → `works/audio/<slug>/` | voice_<时间戳> |
| `--title` | 作品标题 | 记录名 |
| `--desc` | 作品描述 | 自动摘要 |
| `--name` | 历史记录名称 | 自动 |

### 可复现性
- 每次生成写入 SQLite 历史（`scripts/tts_skill.db`），并输出**可复现命令**。
- 播放页每个音轨折叠区都带可复现命令；`studio_tts.py history --show_cmd` 可批量查看。
- 可复现命令带 `--model <ID>`，换引擎重跑只需改 ID。

## models —— 多引擎管理

```bash
python3 studio_tts.py models                    # 模型列表
python3 studio_tts.py models status             # 各模型安装状态
python3 studio_tts.py models install spark-tts  # 安装（建独立 venv + 下载权重）
```

各引擎独立 venv（`.venv-spark` / `.venv-qwen` / `.venv-f5`），避免依赖冲突
（如 qwen-tts 需要旧版 transformers，会破坏 omnivoice）。全量下载方法与选型见
`references/models.md`。

## transcribe —— 音频/视频转文字

| 参数 | 说明 | 默认 |
|---|---|---|
| `--input` | 输入音频/视频文件（**必填**） | - |
| `--model` | whisper 模型：tiny/base/small/medium/large-v3 | large-v3 |
| `--language` | 语言代码（zh/en/ja…），留空自动检测 | 自动 |
| `--task` | `transcribe` 转写 / `translate` 翻译成英文 | transcribe |
| `--device` | cuda/cpu（faster-whisper 不支持 MPS，macOS 自动回退 cpu） | 自动 |
| `--compute_type` | float16 / int8 | cuda→float16, cpu→int8 |
| `--beam_size` | beam search 大小 | 5 |
| `--word_timestamps` | 词级时间戳 | true |
| `--vad_filter` | VAD 静音过滤 | true |
| `--output_dir` | 输出目录 | works/audio/transcribe_<时间戳>/ |
| `--name` | 记录名称 | 自动 |

输出：JSON（词级时间戳 + 分段元数据）+ TXT 纯文本。视频自动经 ffmpeg 提取音轨。

## setup / history / doctor

```bash
python3 studio_tts.py setup [--with_asr] [--force]
python3 studio_tts.py history [--type tts|asr|all] [--show_cmd]
python3 studio_tts.py doctor
```

- `setup`：首次必须。默认仅装 TTS（torch CPU + omnivoice）；`--with_asr` 加装 faster-whisper + ffmpeg。
- 环境装在技能目录内 `scripts/.venv`，不污染系统 Python。
