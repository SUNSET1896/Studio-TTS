"""SQLite 数据库层：统一管理 TTS 记录、ASR 记录、音频库。

使用 Python 标准库 sqlite3，无需额外依赖。
首次运行时自动从 history.json / transcribe_history.json 迁移历史数据。
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any, Optional

from tts_skill.utils import HISTORY_FILE, OUTPUT_DIR, PROJECT_ROOT

logger = logging.getLogger(__name__)

# 数据库文件路径
DB_PATH = PROJECT_ROOT / "tts_skill.db"

# 音频库存储目录（用户上传的参考音频）
LIBRARY_DIR = OUTPUT_DIR / "library"

# 迁移标记文件（迁移完成后创建，避免重复迁移）
MIGRATION_MARKER = PROJECT_ROOT / ".db_migrated"


# ---------------------------------------------------------------------------
# 数据库初始化
# ---------------------------------------------------------------------------


def _get_conn() -> sqlite3.Connection:
    """获取数据库连接（启用 WAL 模式和外键）。"""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db() -> None:
    """初始化数据库表结构。"""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    LIBRARY_DIR.mkdir(parents=True, exist_ok=True)

    with _get_conn() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS tts_records (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                mode TEXT NOT NULL,
                text TEXT NOT NULL,
                ref_audio TEXT,
                ref_audio_id TEXT,
                ref_text TEXT,
                instruct TEXT,
                language TEXT,
                seed INTEGER NOT NULL,
                num_step INTEGER NOT NULL,
                speed REAL NOT NULL,
                duration REAL,
                guidance_scale REAL NOT NULL,
                t_shift REAL NOT NULL,
                denoise INTEGER NOT NULL,
                postprocess_output INTEGER NOT NULL,
                normalize_text INTEGER NOT NULL,
                batch_count INTEGER NOT NULL,
                batch_seeds TEXT NOT NULL,
                output_files TEXT NOT NULL,
                device TEXT,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS asr_records (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                input_file TEXT NOT NULL,
                input_audio_id TEXT,
                file_type TEXT NOT NULL,
                language TEXT,
                language_probability REAL NOT NULL,
                duration REAL NOT NULL,
                model_size TEXT NOT NULL,
                task TEXT NOT NULL,
                device TEXT NOT NULL,
                text TEXT NOT NULL,
                segment_count INTEGER NOT NULL,
                output_files TEXT NOT NULL,
                created_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS audio_library (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                filename TEXT NOT NULL,
                source TEXT NOT NULL,
                mime_type TEXT,
                duration REAL,
                sample_rate INTEGER,
                channels INTEGER,
                file_size INTEGER,
                tags TEXT,
                description TEXT,
                ref_text TEXT,
                related_record_id TEXT,
                created_at TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_tts_timestamp ON tts_records(timestamp);
            CREATE INDEX IF NOT EXISTS idx_asr_timestamp ON asr_records(timestamp);
            CREATE INDEX IF NOT EXISTS idx_audio_source ON audio_library(source);
            CREATE INDEX IF NOT EXISTS idx_audio_created ON audio_library(created_at);
            """
        )

    _migrate_from_json()


def _migrate_from_json() -> None:
    """首次运行时从 JSON 文件迁移历史数据到 SQLite。"""
    if MIGRATION_MARKER.exists():
        return

    migrated_count = 0

    # 迁移 TTS 历史
    if HISTORY_FILE.exists():
        try:
            data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "generations" in data:
                data = data["generations"]
            if isinstance(data, list):
                with _get_conn() as conn:
                    for item in data:
                        try:
                            _insert_tts_record_raw(conn, item)
                            migrated_count += 1
                        except Exception:
                            pass
                logger.info("从 history.json 迁移了 %d 条 TTS 记录", migrated_count)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("迁移 TTS 历史失败: %s", e)

    # 迁移 ASR 历史
    asr_file = PROJECT_ROOT / "transcribe_history.json"
    if asr_file.exists():
        try:
            data = json.loads(asr_file.read_text(encoding="utf-8"))
            if isinstance(data, list):
                asr_count = 0
                with _get_conn() as conn:
                    for item in data:
                        try:
                            _insert_asr_record_raw(conn, item)
                            asr_count += 1
                        except Exception:
                            pass
                logger.info("从 transcribe_history.json 迁移了 %d 条 ASR 记录", asr_count)
                migrated_count += asr_count
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("迁移 ASR 历史失败: %s", e)

    MIGRATION_MARKER.write_text("done\n", encoding="utf-8")
    if migrated_count > 0:
        logger.info("数据库迁移完成，共迁移 %d 条记录", migrated_count)


def _insert_tts_record_raw(conn: sqlite3.Connection, data: dict[str, Any]) -> None:
    """直接插入 TTS 记录（用于迁移，忽略重复）。"""
    valid = {
        "id", "name", "timestamp", "mode", "text",
        "ref_audio", "ref_audio_id", "ref_text", "instruct", "language",
        "seed", "num_step", "speed", "duration", "guidance_scale", "t_shift",
        "denoise", "postprocess_output", "normalize_text",
        "batch_count", "batch_seeds", "output_files", "device",
    }
    filtered = {k: v for k, v in data.items() if k in valid}
    filtered.setdefault("id", str(uuid.uuid4())[:8])
    filtered.setdefault("name", "migrated")
    filtered.setdefault("timestamp", time.strftime("%Y-%m-%d %H:%M:%S"))
    filtered.setdefault("mode", "auto")
    filtered.setdefault("text", "")
    filtered.setdefault("seed", 0)
    filtered.setdefault("num_step", 32)
    filtered.setdefault("speed", 1.0)
    filtered.setdefault("guidance_scale", 2.0)
    filtered.setdefault("t_shift", 0.1)
    filtered.setdefault("denoise", 1)
    filtered.setdefault("postprocess_output", 1)
    filtered.setdefault("normalize_text", 0)
    filtered.setdefault("batch_count", 1)
    filtered.setdefault("batch_seeds", "[]")
    filtered.setdefault("output_files", "[]")
    filtered.setdefault("created_at", filtered["timestamp"])

    # list 字段序列化为 JSON
    if isinstance(filtered.get("batch_seeds"), list):
        filtered["batch_seeds"] = json.dumps(filtered["batch_seeds"])
    if isinstance(filtered.get("output_files"), list):
        filtered["output_files"] = json.dumps(filtered["output_files"])
    # bool 字段转为 int
    for k in ("denoise", "postprocess_output", "normalize_text"):
        if isinstance(filtered.get(k), bool):
            filtered[k] = 1 if filtered[k] else 0

    conn.execute(
        """INSERT OR IGNORE INTO tts_records
           (id, name, timestamp, mode, text, ref_audio, ref_audio_id, ref_text,
            instruct, language, seed, num_step, speed, duration, guidance_scale,
            t_shift, denoise, postprocess_output, normalize_text, batch_count,
            batch_seeds, output_files, device, created_at)
           VALUES (:id, :name, :timestamp, :mode, :text, :ref_audio, :ref_audio_id,
            :ref_text, :instruct, :language, :seed, :num_step, :speed, :duration,
            :guidance_scale, :t_shift, :denoise, :postprocess_output, :normalize_text,
            :batch_count, :batch_seeds, :output_files, :device, :created_at)""",
        filtered,
    )


def _insert_asr_record_raw(conn: sqlite3.Connection, data: dict[str, Any]) -> None:
    """直接插入 ASR 记录（用于迁移，忽略重复）。"""
    valid = {
        "id", "name", "timestamp", "input_file", "input_audio_id", "file_type",
        "language", "language_probability", "duration", "model_size", "task",
        "device", "text", "segment_count", "output_files",
    }
    filtered = {k: v for k, v in data.items() if k in valid}
    filtered.setdefault("id", str(uuid.uuid4())[:8])
    filtered.setdefault("name", "migrated")
    filtered.setdefault("timestamp", time.strftime("%Y-%m-%d %H:%M:%S"))
    filtered.setdefault("input_file", "")
    filtered.setdefault("file_type", "audio")
    filtered.setdefault("language_probability", 0.0)
    filtered.setdefault("duration", 0.0)
    filtered.setdefault("model_size", "base")
    filtered.setdefault("task", "transcribe")
    filtered.setdefault("device", "cpu")
    filtered.setdefault("text", "")
    filtered.setdefault("segment_count", 0)
    filtered.setdefault("output_files", "[]")
    filtered.setdefault("created_at", filtered["timestamp"])

    if isinstance(filtered.get("output_files"), list):
        filtered["output_files"] = json.dumps(filtered["output_files"])

    conn.execute(
        """INSERT OR IGNORE INTO asr_records
           (id, name, timestamp, input_file, input_audio_id, file_type, language,
            language_probability, duration, model_size, task, device, text,
            segment_count, output_files, created_at)
           VALUES (:id, :name, :timestamp, :input_file, :input_audio_id, :file_type,
            :language, :language_probability, :duration, :model_size, :task, :device,
            :text, :segment_count, :output_files, :created_at)""",
        filtered,
    )


# ---------------------------------------------------------------------------
# TTS 记录 CRUD
# ---------------------------------------------------------------------------


def _row_to_tts_dict(row: sqlite3.Row) -> dict[str, Any]:
    """将数据库行转为 TTS 记录字典。"""
    d = dict(row)
    d["batch_seeds"] = json.loads(d.get("batch_seeds") or "[]")
    d["output_files"] = json.loads(d.get("output_files") or "[]")
    d["denoise"] = bool(d.get("denoise", 1))
    d["postprocess_output"] = bool(d.get("postprocess_output", 1))
    d["normalize_text"] = bool(d.get("normalize_text", 0))
    return d


def db_load_tts_history() -> list[dict[str, Any]]:
    """加载所有 TTS 记录（按时间倒序）。"""
    with _get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM tts_records ORDER BY timestamp DESC"
        ).fetchall()
    return [_row_to_tts_dict(r) for r in rows]


def db_get_tts_record(record_id: str) -> Optional[dict[str, Any]]:
    """根据 ID 获取 TTS 记录。"""
    with _get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM tts_records WHERE id = ?", (record_id,)
        ).fetchone()
    return _row_to_tts_dict(row) if row else None


def db_add_tts_record(data: dict[str, Any]) -> None:
    """添加一条 TTS 记录。"""
    with _get_conn() as conn:
        _insert_tts_record_raw(conn, data)
        conn.commit()


def db_update_tts_name(record_id: str, new_name: str) -> bool:
    """更新 TTS 记录名称。"""
    with _get_conn() as conn:
        cur = conn.execute(
            "UPDATE tts_records SET name = ? WHERE id = ?",
            (new_name, record_id),
        )
        conn.commit()
        return cur.rowcount > 0


def db_delete_tts_record(record_id: str) -> bool:
    """删除 TTS 记录。"""
    with _get_conn() as conn:
        cur = conn.execute(
            "DELETE FROM tts_records WHERE id = ?", (record_id,)
        )
        conn.commit()
        return cur.rowcount > 0


# ---------------------------------------------------------------------------
# ASR 记录 CRUD
# ---------------------------------------------------------------------------


def _row_to_asr_dict(row: sqlite3.Row) -> dict[str, Any]:
    """将数据库行转为 ASR 记录字典。"""
    d = dict(row)
    d["output_files"] = json.loads(d.get("output_files") or "[]")
    return d


def db_load_asr_history() -> list[dict[str, Any]]:
    """加载所有 ASR 记录（按时间倒序）。"""
    with _get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM asr_records ORDER BY timestamp DESC"
        ).fetchall()
    return [_row_to_asr_dict(r) for r in rows]


def db_get_asr_record(record_id: str) -> Optional[dict[str, Any]]:
    """根据 ID 获取 ASR 记录。"""
    with _get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM asr_records WHERE id = ?", (record_id,)
        ).fetchone()
    return _row_to_asr_dict(row) if row else None


def db_add_asr_record(data: dict[str, Any]) -> None:
    """添加一条 ASR 记录。"""
    with _get_conn() as conn:
        _insert_asr_record_raw(conn, data)
        conn.commit()


def db_update_asr_name(record_id: str, new_name: str) -> bool:
    """更新 ASR 记录名称。"""
    with _get_conn() as conn:
        cur = conn.execute(
            "UPDATE asr_records SET name = ? WHERE id = ?",
            (new_name, record_id),
        )
        conn.commit()
        return cur.rowcount > 0


def db_delete_asr_record(record_id: str) -> bool:
    """删除 ASR 记录。"""
    with _get_conn() as conn:
        cur = conn.execute(
            "DELETE FROM asr_records WHERE id = ?", (record_id,)
        )
        conn.commit()
        return cur.rowcount > 0


# ---------------------------------------------------------------------------
# 音频库 CRUD
# ---------------------------------------------------------------------------


def _row_to_audio_dict(row: sqlite3.Row) -> dict[str, Any]:
    """将数据库行转为音频库记录字典。"""
    d = dict(row)
    d["tags"] = json.loads(d.get("tags") or "[]")
    return d


def db_list_audio(
    source: Optional[str] = None,
    limit: int = 500,
) -> list[dict[str, Any]]:
    """列出音频库记录（按创建时间倒序）。"""
    with _get_conn() as conn:
        if source:
            rows = conn.execute(
                "SELECT * FROM audio_library WHERE source = ? ORDER BY created_at DESC LIMIT ?",
                (source, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM audio_library ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
    return [_row_to_audio_dict(r) for r in rows]


def db_get_audio(audio_id: str) -> Optional[dict[str, Any]]:
    """根据 ID 获取音频记录。"""
    with _get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM audio_library WHERE id = ?", (audio_id,)
        ).fetchone()
    return _row_to_audio_dict(row) if row else None


def db_add_audio(data: dict[str, Any]) -> str:
    """添加一条音频库记录，返回 audio_id。"""
    audio_id = data.get("id") or str(uuid.uuid4())[:8]
    with _get_conn() as conn:
        conn.execute(
            """INSERT INTO audio_library
               (id, name, filename, source, mime_type, duration, sample_rate,
                channels, file_size, tags, description, ref_text,
                related_record_id, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                audio_id,
                data.get("name", ""),
                data["filename"],
                data.get("source", "upload"),
                data.get("mime_type"),
                data.get("duration"),
                data.get("sample_rate"),
                data.get("channels"),
                data.get("file_size"),
                json.dumps(data.get("tags", []), ensure_ascii=False),
                data.get("description"),
                data.get("ref_text"),
                data.get("related_record_id"),
                data.get("created_at", time.strftime("%Y-%m-%d %H:%M:%S")),
            ),
        )
        conn.commit()
    return audio_id


def db_update_audio(audio_id: str, updates: dict[str, Any]) -> bool:
    """更新音频记录（支持 name / tags / description / ref_text）。"""
    allowed = {"name", "tags", "description", "ref_text"}
    fields = {k: v for k, v in updates.items() if k in allowed}
    if not fields:
        return False

    if "tags" in fields:
        fields["tags"] = json.dumps(fields["tags"], ensure_ascii=False)

    set_clause = ", ".join(f"{k} = ?" for k in fields)
    values = list(fields.values()) + [audio_id]

    with _get_conn() as conn:
        cur = conn.execute(
            f"UPDATE audio_library SET {set_clause} WHERE id = ?", values
        )
        conn.commit()
        return cur.rowcount > 0


def db_delete_audio(audio_id: str) -> Optional[str]:
    """删除音频记录，返回文件名（供调用方删除磁盘文件）。"""
    audio = db_get_audio(audio_id)
    if not audio:
        return None
    with _get_conn() as conn:
        conn.execute("DELETE FROM audio_library WHERE id = ?", (audio_id,))
        conn.commit()
    return audio["filename"]


def db_register_generated_audio(
    filename: str,
    source: str,
    related_record_id: str,
    name: Optional[str] = None,
    duration: Optional[float] = None,
    sample_rate: Optional[int] = None,
) -> str:
    """注册一个生成的音频到音频库。"""
    return db_add_audio({
        "name": name or filename,
        "filename": filename,
        "source": source,
        "duration": duration,
        "sample_rate": sample_rate,
        "related_record_id": related_record_id,
    })
