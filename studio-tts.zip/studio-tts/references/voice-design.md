# 声音设计属性参考（design 模式）

`--mode design` 用自然语言属性描述声音，多个属性用逗号连接，中英文均可。
模型按属性生成对应声线；`--instruct` 留空则自动。建议一次 3–8 个属性。

## 类别与选项

| 类别 | 选项（中文 / English） |
|---|---|
| 性别 | 男 / Male、女 / Female |
| 年龄 | 儿童 / Child、少年 / Teenager、青年 / Young Adult、中年 / Middle-aged、老年 / Elderly |
| 音调 | 极低音调 / Very Low Pitch、低音调 / Low Pitch、中音调 / Moderate Pitch、高音调 / High Pitch、极高音调 / Very High Pitch |
| 风格 | 耳语 / Whisper |
| 英文口音 | 美式 / American、英式 / British、澳大利亚 / Australian、加拿大 / Canadian、印度 / Indian、中国 / Chinese、日本 / Japanese、韩国 / Korean、葡萄牙 / Portuguese、俄罗斯 / Russian |
| 中文方言 | 河南话、陕西话、四川话、贵州话、云南话、桂林话、济南话、石家庄话、甘肃话、宁夏话、青岛话、东北话 |

## 常用组合示例

```bash
# 沉稳的中年男声（守店老师傅、长辈）
--instruct "male, middle-aged, low pitch"

# 清亮少女声（主角、妹妹）
--instruct "female, teenager, high pitch"

# 沙哑耳语（神秘 NPC、夜谈）
--instruct "male, middle-aged, whisper"

# 英式青年男声（异国来客）
--instruct "male, young adult, british accent"

# 东北话大叔
--instruct "男, 中年, 东北话"
```

## 与角色绑定的用法

给世界角色配固定声线时，把同一组 `--instruct`（或同一 clone 参考音频 + seed）
记进角色的材料档案（如 voice 字段），后续每次用相同参数生成即得到同一角色的声音。
批量探索时用 `--batch_count 5` 一次出 5 个候选，选中后记下其 seed。
