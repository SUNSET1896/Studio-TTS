#!/usr/bin/env python3
"""F5-TTS 后端 runner。由 .venv-f5/bin/python 执行。

用法: python run_f5.py <args.json> <output.wav>

args.json 字段:
  text       必填
  ref_audio  参考音频（F5 是零样本克隆模型，clone 模式必需）
  ref_text   参考音频文本
  seed       随机种子
  device     cpu / cuda

注意：F5-TTS 必须提供参考音频才能合成（纯克隆模型，无 design/auto 模式）。
"""

from __future__ import annotations

import json
import sys

import numpy as np
import soundfile as sf
import torch


def main() -> int:
    args = json.load(open(sys.argv[1], encoding="utf-8"))
    out_path = sys.argv[2]
    device = args.get("device") or ("cuda" if torch.cuda.is_available() else "cpu")

    if not args.get("ref_audio"):
        print(json.dumps({"ok": False, "error": "F5-TTS 需要参考音频（--mode clone --ref_audio）"}))

        return 1

    from f5_tts.api import F5TTS

    tts = F5TTS(device=device, use_ema=True)
    if args.get("seed") is not None:
        torch.manual_seed(int(args["seed"]))
        np.random.seed(int(args["seed"]))

    try:
        wav, sr, _ = tts.infer(
            text=args["text"],
            ref_file=args["ref_audio"],
            ref_text=args.get("ref_text") or "",
        )
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"{type(e).__name__}: {e}"}))
        return 1

    audio = np.asarray(wav).squeeze()
    sf.write(out_path, audio, sr)
    print(json.dumps({"ok": True, "sr": sr, "duration": round(len(audio) / sr, 3)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
