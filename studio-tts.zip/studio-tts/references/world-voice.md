# 世界观适配工作流 — 读世界、理故事、问用户、配声线、写回世界

本技能在 Studio 世界内默认按此流程工作：**每次配声线前先读这个世界**，把角色、地点、
事件、已有声线摆到台面上，问清楚做哪一段，生成后把声线写回世界，让声音成为世界的
可复用资产（同一角色永远同一把嗓子）。

配合 `studio_tts.py world` 子命令（世界观声线盘点，无需 TTS 环境）使用。

## 0. 核心原则

- **先读世界，再开口**。不凭空问"要配什么"——把这个世界能配的东西列出来再问。
- **每次生成前询问用户**：制作哪部分 / 哪个角色 / 哪个环节的旁白。这是本工作流的
  硬约束（用户明确要求），不允许擅自选段。
- **同一角色永远用同一把声音**：绑定（engine + mode + instruct/ref + seed）写回角色
  材料，后续生成自动复用。
- **旁白是世界的叙述者**：按世界基调设计一条声线并存档（`works/audio/narrator/
  binding.json`），但每次生成前仍要询问用户。

## 1. 读世界（World Intake）

快速盘点一行命令：

```bash
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py world          # 可读报告
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py world --json   # 结构化数据
```

要读全的信息（`world` 命令只给骨架，细节要读材料原文）：

- `manifest.json`：`worldConfig` 的 genre / tone / era / seedPrompt（世界基调与开场种子）
- 角色材料（`materials/character/*.json` 或 `neta atom get <id>`）：`description` +
  `content` 全部键（身份 / 外观 / 性格 / 经历 / 关系…）
- 地点、事件、传说材料：同样全读，事件按时间/因果排序即主线
- 已有语音作品：`works/audio/*/tracks.json`（engine / mode / instruct / seed / text）
- 旁白档案：`works/audio/narrator/binding.json`

## 2. 理故事（Story Spine）

- **主线**：按事件材料（或描述中的时间顺序）排一条主轴。
- **分线**：角色各自的线、地点承载的线、材料间关系（谁在哪、和谁相关）。
- **环境**：地点材料 + worldConfig 基调。
- **产出**：一张"可配音环节"清单，每项标注类型——角色台词 / 场景旁白 / 主线叙述 /
  分线叙述，并带角色名、地点名、事件名。

## 3. 盘点声线（Voice Inventory）

- 谁**已有声线**：角色材料 `content` 键 `声线`（或 `voice`），值为绑定串。
- 谁**有声线作品但未写回材料**：`world` 命令标为「待绑定」。
- 旁白**是否已建档**：`narrator/binding.json` 是否存在。

绑定串格式（一行，写进角色材料）：

```
engine=<模型ID>; mode=<auto|design|clone>; instruct="<属性描述>"; seed=<种子>
# clone 模式用 ref_audio=<参考音频路径> 代替 instruct
```

## 4. 询问（Ask）

**必问**：制作哪部分 / 哪个角色 / 哪个环节的旁白。形式二选一：

- 推荐：用 `neta questionnaire` 出一轮菜单，选项直接带世界真实名字（角色名、地点名、
  事件名）；角色已有声线的选项标注"复用已有声线（engine=…, instruct=…, seed=…）"。
- 或对话直接问。

用户只指了角色/环节、没给文本时：由 agent 依据材料写台词或旁白文本，**生成前给用户
过目确认**再跑。

## 5. 生成（Generate）

- 角色**已有声线**：原样复用绑定（engine + mode + instruct/ref + seed——seed 是复现关键）。
- 角色**无声线**：
  - 按材料设计：从性别 / 年龄 / 性格 / 口音推 `--instruct`（见 `voice-design.md`）；
  - 或用户提供 3–10 秒参考音频 → `clone`。
- **旁白**：按世界基调设计叙述者声线（例：公路故事 → `male, middle-aged, low pitch,
  calm`）；首次生成后存档（见第 6 步）。
- 生成命令照常（可复现）：`voice --text "…" --mode design --instruct "…" --seed N
  --model <ID> --slug <slug>`。

## 6. 回写（Bind Back）

- **角色声线**：写回材料 `content` 键 `声线`。用 `neta atom update`（patch 传
  `metadata` 或 `content`；写后 `neta atom get` 验证落盘；若 CLI 整表替换 content，
  先把原 content 一并带回 patch）。
- **旁白声线**：写 `works/audio/narrator/binding.json`：

  ```json
  {
    "engine": "spark-tts",
    "mode": "design",
    "instruct": "male, middle-aged, low pitch, calm",
    "seed": 11,
    "desc": "世界旁白声线（按世界基调设计）",
    "updatedAt": "2026-08-29T00:00:00"
  }
  ```

- 语音作品发布照常：`neta work init web` + `neta work publish web`。

## 7. 质量检查（world 版）

- [ ] `world` 盘点跑过：角色 / 地点 / 事件 / 已有声线都在报告里
- [ ] 询问过用户：哪部分 / 哪个角色 / 哪段旁白，未擅自选段
- [ ] 复用：角色已有声线时，engine + instruct + seed 与原绑定一致
- [ ] 回写：新角色声线已写入材料（`content` 键 `声线`）；旁白已写入 `narrator/binding.json`
- [ ] 语音作品已发布（`work init` + `work publish`）或交付文件路径 + 可复现命令

## 示例（通用模板，执行时把 `<占位符>` 替换为当前世界真实内容）

技能本身不含任何世界具体内容；以下只是格式模板：

- 世界基调：从 `manifest.json` 的 `worldConfig`（genre / tone / era / seedPrompt）读出。
- 角色盘点（每角色一行）：`<角色名>`（声线作品 `<slug>`：`<engine>`, `<instruct>`, seed=`<seed>`，绑定状态）。
- 旁白档案：已建档 / 未建档。
- 询问菜单（questionnaire 三选项模板）：
  1. 给 `<角色名>` 配一句新台词（复用已有声线 `<engine>`, instruct="<instruct>", seed=`<seed>`）
  2. 给 `<角色名>` 配一段 `<场景/环节>` 的台词（无声线则按材料设计或克隆）
  3. 按世界基调设计一条旁白声线并存档（如 `<性别/年龄/音调>`，平静）
