#!/usr/bin/env bash
# Studio TTS · 安装后初始化
#
# 激活主环境（scripts/.venv）并跑一次 setup，让技能「装完即用」，
# 而不是等到第一次使用时才装环境。
#
# 用法：
#   bash install.sh              # 仅 TTS 主环境（torch CPU + OmniVoice）
#   bash install.sh --with_asr   # 加装语音转文字（faster-whisper + ffmpeg）
#
# 首次约 10–20 分钟；幂等——主环境已就绪时直接跳过，可随时重跑。
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$DIR/scripts/studio_tts.py"

echo "== 初始化主环境（激活 scripts/.venv）并运行 setup =="
python3 "$PY" setup "$@"

echo
echo "== 安装完成，技能已就绪 =="
echo "  环境诊断:   python3 $PY doctor"
echo "  引擎状态:   python3 $PY models status"
echo "  安装引擎:   python3 $PY models install <ID>   # spark-tts / qwen3-tts / f5-tts"
echo "  声线盘点:   python3 $PY world"
