# Studio TTS · 技能包

一个 Studio 适配的文本转语音 / 声音克隆 / 语音转文字技能发布包，格式遵循
agentskills.io 规范（技能目录内含 `SKILL.md` 与可选资源），在支持 skills 的环境
（Neta Studio / Codex / 其他 agentskills 兼容宿主）中均可安装。

本技能制作时参考了 tts-skill（https://github.com/boommanpro/tts-skill，MIT，基于
OmniVoice + faster-whisper），十分感谢作者的分享。
本包是它的 Studio 适配版：保留 CLI 生成/转写核心，去掉 Web 服务与前端；**多引擎
可切换**（Qwen3-TTS 默认 / OmniVoice / Spark-TTS / F5-TTS / CosyVoice 2 /
IndexTTS2 / Fish Speech），每个引擎独立 venv，互不污染；产出 `works/audio/<slug>/`
语音作品（wav + mp3 + 播放页 + tracks.json），可发布为 Studio Work。

## 包含内容

| 技能 | 作用 | 资源 |
|---|---|---|
| `studio-tts` | 文本转语音（auto 自动 / design 声音设计 / clone 声音克隆）；音频/视频转文字（词级时间戳）；随机种子可复现；**多模型可选**（`voice --model <ID>`，`models install <ID>` 下载权重）；**世界观适配**（`world` 子命令盘点 + 读世界→理故事→询问→生成→回写工作流） | `references/params.md`（参数表）、`references/voice-design.md`（声音属性）、`references/models.md`（多引擎下载方法与选型）、`references/studio-integration.md`（发布/交付/错误处理）、`references/world-voice.md`（世界观适配工作流）、`scripts/`（studio_tts.py + backends/ 外部引擎 runner + `requirements*.txt` 依赖清单 + vendored tts_skill 包 + Spark-TTS 源码） |

## 安装方法

### 方式一：复制到技能目录（推荐）

```bash
# REPO 作用域（项目/世界内，团队共享）
cp -r studio-tts /workspace/.agents/skills/

# USER 作用域（个人跨项目通用）
cp -r studio-tts ~/.agents/skills/

# ADMIN 作用域（机器级，需权限）
cp -r studio-tts /etc/codex/skills/
```

### 方式二：解压 zip

```bash
unzip studio-tts-package.zip -d /workspace/.agents/skills/
```

### 安装后初始化（装完即用）

任选一种方式复制完成后，**激活主环境并跑一次 setup**（首次约 10–20 分钟）：

```bash
cd <技能目录>/studio-tts
bash install.sh --with_asr   # 推荐：含语音转文字（faster-whisper + ffmpeg）
# 仅要 TTS 主环境：bash install.sh
```

`install.sh` 会创建/激活主环境 `scripts/.venv` 并安装 torch + OmniVoice（+ 可选 ASR），
**幂等**——主环境已就绪时直接跳过，可随时重跑；也可用 `--force` 强制重装。

## 使用

安装后重启 / 重载宿主，技能按需自动触发。首次使用：

```bash
# 0. 读世界（世界观适配，无需 TTS 环境）：角色/地点/事件/已有声线盘点
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py world

# 1. 初始化主环境（OmniVoice + ASR + 魔搭 SDK，约 10–20 分钟）
#    安装时已跑 install.sh 则自动跳过（幂等）；未初始化才需要本步
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py setup --with_asr

# 2. 查看/安装引擎（默认引擎 qwen3-tts 全部公开变体，免 token）
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py models

# 3. 生成语音（不传 --model 即用默认引擎 qwen3-tts）
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py voice \
  --text "你好，欢迎。" --mode design --instruct "亲切温柔的女声" --seed 1 --slug hello

# 想用 CPU 直接可跑的引擎：voice --model omnivoice / --model spark-tts

# 4. 把声线写回角色材料（下次自动复用同一把声音；--dry-run 先预览）
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py bind \
  --slug <slug> --character <角色名>
```

转写素材：

```bash
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py transcribe --input meeting.mp4 --language zh
```

语音产出落成 `works/audio/<slug>/`（wav + mp3 + 播放页 + tracks.json），由执行
agent 走 `neta work init web` + `neta work publish web` 发布为 Studio Work。

## 默认引擎：qwen3-tts（免 token）

本包默认引擎是 Qwen3-TTS。权重**公开可拉，无需登录**：

- design → `Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice`（HF / 魔搭均可匿名拉取；
  用内置 speaker + 自然语言语气实现音色设计）
- clone → `Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice`
- auto → `Qwen/Qwen3-TTS-12Hz-0.6B-Base`

`models install qwen3-tts` 一键装环境；首次 `voice` 自动下载对应变体权重
（~1.5GB/个）。
**注意**：`Qwen/Qwen3-TTS-12Hz-0.6B-VoiceDesign` 变体在 HF 与魔搭均受限
（需登录接受许可 + token），已从默认映射中移除；若坚持用它，需 `HF_TOKEN`
或 `MODELSCOPE_API_TOKEN`。

## 模型下载权限速查（2026-08 实测）

**全部 7 个引擎的权重均可匿名下载**，没有一个需要登录：

| 模型 | 权重下载 | 说明 |
|---|---|---|
| OmniVoice | ✅ 公开 | HF + 魔搭均可 |
| Spark-TTS | ✅ 公开 | HF + 魔搭均可（实测下载） |
| Qwen3-TTS（默认变体） | ✅ 公开 | CustomVoice / Base 全系，HF + 魔搭均可 |
| F5-TTS | ✅ 公开 | HF |
| Fish Speech 1.5 | ✅ 公开 | HF；引擎需手动 conda 3.12 |
| CosyVoice 2 | ✅ 公开（魔搭 `iic/CosyVoice2-0.5B`） | 实测 clone + LFS 成功；HF 上仍受限；引擎需手动 conda |
| IndexTTS2 | ✅ 公开（魔搭 `IndexTeam/IndexTTS-2`） | 实测 clone + LFS（1.2GB）成功；HF 上仍受限；引擎需手动 uv |
| faster-whisper（ASR） | ✅ 公开 | HF + 魔搭 |

> 下载能解锁 ≠ 引擎能跑：CosyVoice 2 / IndexTTS2 / Fish Speech 的权重都公开了，
> 但运行环境仍需手动搭（conda/uv 独立环境 + GPU）；CPU 沙箱内可直接跑的是
> OmniVoice、Spark-TTS、Qwen3-TTS。

## 国内网络：ModelScope（魔搭）下载源 —— 推荐

魔搭（modelscope.cn，阿里系）是 huggingface.co 之外的独立仓库：

```bash
python3 studio_tts.py models install spark-tts --source modelscope   # 一键走魔搭
# 或环境变量默认：export MODELSCOPE_HUB=1
# 或 CLI：pip install -U modelscope && modelscope download --model <repo> --local_dir <dir>
```

魔搭可用仓库（全部实测）：`k2-fsa/OmniVoice`、`SparkAudio/Spark-TTS-0.5B`、
`Qwen/Qwen3-TTS-12Hz-0.6B-{CustomVoice,Base}`、**`iic/CosyVoice2-0.5B`**、
**`IndexTeam/IndexTTS-2`**、`SWivid/F5-TTS`、`fishaudio/fish-speech-1.5`、
`Systran/faster-whisper-large-v3`（ASR）。

## 国内网络：hf-mirror 镜像站（CLI 方法）

hf-mirror.com 是 huggingface.co 的国内公益镜像，官方 CLI 用法：

```bash
pip install -U huggingface_hub
export HF_ENDPOINT=https://hf-mirror.com
hf download Qwen/Qwen3-TTS-12Hz-0.6B-CustomVoice --local-dir ./CustomVoice
# 旧版命令：huggingface-cli download --resume-download <repo> --local-dir <dir>
```

本技能尊重 `HF_ENDPOINT` 环境变量（用户设置了就按镜像走，没设则直连官方源）。
注意：镜像只加速公开仓库，受限仓库仍需 token（当前唯一受限的是 Qwen
`0.6B-VoiceDesign`，已弃用）。海外/直连环境（如阿里云美西沙箱）镜像会把流量
308 重定向回源站，直连反而更快。

## 依赖清单（requirements）

每个环境的依赖都有独立清单，`models install` 按文件安装：

| 文件 | 对应环境 | 内容 |
|---|---|---|
| `scripts/requirements.txt` | 主环境 `.venv`（OmniVoice + ASR + 魔搭 SDK） | omnivoice / soundfile / numpy / **transformers>=5.16（锁）** / **modelscope** / faster-whisper / imageio-ffmpeg / num2words |
| `scripts/requirements-spark.txt` | `.venv-spark` | einops / einx / omegaconf / safetensors / soxr / transformers==4.46.2 等 |
| `scripts/requirements-qwen.txt` | `.venv-qwen` | qwen-tts==0.1.1 / transformers==4.57.3 / accelerate==1.12.0 / librosa 等 |
| `scripts/requirements-f5.txt` | `.venv-f5` | f5-tts |

torch / torchaudio 由安装流程按平台单独安装（本沙箱为 CPU 索引 2.8.0+cpu），
不写在 requirements 内（避免 CUDA/CPU 冲突）。

## 多引擎说明

- 默认引擎 **`qwen3-tts`**（免 token）；`omnivoice` 随 setup 安装（CPU 直接可跑，
  想切回用 `voice --model omnivoice`）；`spark-tts` 已验证可跑（CPU 友好）；
  `f5-tts` pip 可装；`cosyvoice2`（权重魔搭公开可拉，引擎需 conda 独立环境）/
  `index-tts2`（权重魔搭公开可拉，引擎需 uv）/ `fish-speech`（权重公开，引擎需
  conda 3.12），`models install` 会打印精确手动步骤。
- 每个引擎独立 venv（`.venv-spark` / `.venv-qwen` / `.venv-f5`），避免依赖冲突
  （如 qwen-tts 会降级 transformers 破坏 omnivoice；主环境已锁 transformers>=5.16）。
- 权重下载源三选一：HuggingFace 直连（默认）/ ModelScope 魔搭（`--source
  modelscope` 或 `MODELSCOPE_HUB=1`）/ hf-mirror 镜像（`HF_ENDPOINT`）。
- 选型依据《2026 开源 TTS 选型指南》：中文首选 CosyVoice 2、低延迟 Qwen3-TTS、
  情感控制 IndexTTS2、无 GPU 用 Spark-TTS。
- 权重不打包（数百 MB 到数 GB），由 `models install` 按需下载；模型缓存
  （HF 默认 `~/.cache/huggingface`，魔搭默认 `~/.cache/modelscope`）所有世界共用。

## 说明

- 技能文件内不含任何具体产品/世界观内容，全部参数化——文本、声音属性、参考音频
  由调用方传入，换任何角色/语言/素材均可复用。
- 适配时修复的上游问题（均以注释留在 vendored 代码中）：pip 镜像 `--index-url`
  与 `-i` 冲突、PEP 668 环境隔离、`PIP_USER` 注入、CPU 上 float16 不可用、
  hf-mirror 重定向导致的模型下载失败（改为真实网络探测 + 尊重用户 HF_ENDPOINT）、
  可复现命令改为 Studio 原生 `studio_tts.py voice` 形式。
