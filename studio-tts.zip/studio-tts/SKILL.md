---
name: studio-tts
description: >-
  Studio 版文本转语音 / 声音克隆 / 声音设计 / 语音转文字技能：一行命令让文本发出
  任何人的声音，或让音频/视频变成带词级时间戳的文字。基于 OmniVoice + faster-whisper
  （原型：https://github.com/boommanpro/tts-skill，MIT）。产出：works/audio/<slug>/
  下的语音作品（wav/mp3 + 播放页 + 复现命令），或转写 txt/json，可发布为 Studio Work。
  在 Studio 世界内默认走世界观适配工作流：先读世界观（角色/地点/事件/主线分线），再询问
  用户制作哪部分、哪个角色、哪个环节的旁白，生成后把声线写回世界自动复用。
  当用户说「给这个角色配音」「让 TA 说这句话」「生成台词/旁白语音」「克隆某个声音」
  「按属性设计一个声音」「把这段音频/视频转成文字」「提取字幕」「TTS」「语音合成」
  （English: "text to speech", "voice clone", "voice over", "narrate this",
  "transcribe this audio/video"）时使用。
  不要用于：音乐/配乐生成（那是 neta generate audio）、语音聊天机器人（那是
  create-roleplay）、给角色做画像（那是 generate 图片流程）。
---

# Studio TTS — 语音生成 / 转写技能

把「文本 → 任何人声」「音频/视频 → 文字」做成 Studio 世界内的一行命令。
技能是**功能方法论**：不含任何世界具体内容，文本、声音属性、参考音频全部由调用方
传入；换任何角色、任何语言、任何素材都按同一套流程稳定产出。

运行时 vendored 在本技能 `scripts/` 下（上游 tts-skill 的精简版 + Studio 适配层），
自带 venv，首次使用自动安装（torch CPU + omnivoice，可选 faster-whisper）。

## 何时使用本技能

- 用户要**给角色配音**：让某个角色说一句台词、一段旁白、一句问候。
- 用户要**声音克隆**：给一段 3–10 秒参考音频，复刻那个声音说新文本。
- 用户要**声音设计**：按性别/年龄/音调/口音/方言描述，凭空造一条声线。
- 用户要**批量探索**：同文本多种子生成，挑最好听的记下 seed。
- 用户要**语音转文字**：把音频/视频文件转成文字（含词级时间戳、可翻译成英文）。

## 何时不用本技能

- 音乐、配乐、环境音、音效 → `neta generate audio`（suno）。
- 想和角色实时聊天/角色扮演 → `create-roleplay`。
- 只想要图片/角色立绘 → `generate` 图片流程。
- 想让已有语音网页换个皮肤 → `create-web-work`。

## 世界观适配工作流（Studio 世界内默认流程）

本技能在 Studio 世界内默认走「世界观感知」流程：**先读世界，再问你配哪段，生成后把
声线写回世界**。完整方法论见 `references/world-voice.md`，快速盘点用 `world` 子命令。

1. **读世界** → 读 `manifest.json` 与全部材料（角色/地点/事件/传说），提取人物全信息、
   环境与基调；跑 `studio_tts.py world` 拿声线盘点。
2. **理故事** → 按事件/场景理顺主线与分线，标出可配音的环节（角色台词、场景旁白、
   主线/分线叙述）。
3. **盘点声线** → 已有语音作品（`works/audio/*/tracks.json`）与角色绑定状态、旁白档案。
4. **询问** → 必问用户：制作哪部分 / 哪个角色 / 哪个环节旁白；用 `neta questionnaire`
   出一轮基于世界真实内容的候选菜单（角色名、地点名、事件名直接带入），或对话询问。
5. **生成** → 角色已有声线则复用绑定（engine+mode+instruct/ref+seed）；无声线则按
   人物材料设计（`voice-design.md`）或克隆；旁白按世界基调设计叙述者声线。
6. **回写** → 角色声线写回材料（用 `bind` 子命令写 `content` 键 `声线`）；旁白声线
   存 `works/audio/narrator/binding.json`；下次生成自动复用同一把声音。

## 能力骨架（不变核心）

### 四条主命令

| 命令 | 输入 | 输出 |
|---|---|---|
| `setup [--with_asr]` | 无（首次运行） | 就绪的主环境（OmniVoice + ASR）；默认引擎 qwen3-tts 另需 `models install qwen3-tts`（权重公开免 token） |
| `voice --model <ID>` | `--text` 必填 + 模式参数 | `works/audio/<slug>/`：wav + mp3 + 播放页 + tracks.json |
| `transcribe` | `--input` 音频/视频文件 | `works/audio/transcribe_<时间戳>/`：json + txt |
| `models` | list / status / install <ID> | 模型列表 / 安装状态 / 下载并安装指定模型 |
| `history / doctor` | 无 | 历史记录 / 环境诊断 |
| `world` | 无（读 manifest + 材料 + 已有语音作品） | 世界观声线盘点：角色/地点/事件 + 声线绑定状态（`--json` 结构化） |
| `bind` | `--character`/`--atom` + `--slug` 或显式参数 | 把声线写回材料 `content` 键 `声线`（`--dry-run` 预览） |

### 多引擎（可自行选择 TTS 模型）

`voice --model <ID>` 支持：`qwen3-tts`（**默认**，全部公开变体免 token）、`omnivoice`（已装，
CPU 直接可跑）、`spark-tts`（CPU 友好，已装）、`f5-tts`；`cosyvoice2` / `index-tts2` /
`fish-speech` 为手动安装（conda/GPU 独立环境）。每个引擎独立 venv，互不污染。

- 安装：`python3 studio_tts.py models install <ID>`（自动建 venv、装依赖、下载权重）；
  国内可加 `--source modelscope` 走魔搭下载（全部模型在魔搭都有镜像仓库）
- 全量说明：`references/models.md`（下载方法、选型对比、注意事项）
- 引擎选择依据《2026 开源 TTS 选型指南》：中文首选 CosyVoice 2、低延迟 Qwen3-TTS、
  情感控制 IndexTTS2、CPU 无 GPU 用 Spark-TTS

### 三种生成模式（voice --mode）

- `auto`：只给文本，模型自动选声线（最快验证）。
- `design`：`--instruct "male, middle-aged, low pitch"` 按属性生成（给角色造声线）。
- `clone`：`--ref_audio ref.wav [--ref_text "参考文本"]` 克隆参考声音（复刻真人/已有声线）。

### 数据流（每步的输入 → 动作 → 输出）

1. **读世界/调参** → 先按「世界观适配工作流」读世界、理故事、询问用户做哪段；
   再确定文本、模式、**引擎（--model）**、种子、批量数；design 模式参考
   `references/voice-design.md` 选属性，多引擎对照 `references/models.md`。
2. **生成** → 运行 `voice`；同种子 + 同参数 = 同音频（可复现）；批量时每个独立 seed。
   外部引擎（spark/qwen/f5）跑在各自独立 venv 的后端 runner 里，不污染主环境。
3. **落盘** → wav（原始）+ mp3（网页播放）写进 `works/audio/<slug>/audio/`；
   播放页 `index.html` 列出全部音轨（每个折叠区含可复现命令）；
   `tracks.json` 给程序化消费（AVG 配音、角色卡语音等），含 engine 字段。
4. **发布**（语音）→ `neta work init web` + `neta work publish web`（见
   `references/studio-integration.md`）。
5. **交付** → 用 interaction-components 交付 Work 链接或文件路径；附可复现命令。
6. **转写**（独立路径）→ `transcribe` 输出 json/txt，直接交付文件路径。

### 可复现性（本技能最重要的不变约束）

- 固定 `--seed` + 全部生成参数 = 完全相同的音频。
- 每次生成写入 SQLite 历史，可复现命令随时可取（播放页 / `history --show_cmd`）。
- 给角色配声线时，把 `instruct`（或参考音频）+ seed 记进角色材料档案，即可稳定复用。

## 构建流程（agent 执行）

```bash
# 0. 读世界（世界观适配，无需 TTS 环境）：角色/地点/事件/已有声线盘点
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py world

# 0. 首次：装环境（TTS 约 10–20 分钟；需要转写就加 --with_asr）
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py setup --with_asr

# 1. 生成语音（示例：声音设计模式）
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py voice \
  --text "你好，欢迎来到这里。" \
  --mode design --instruct "male, middle-aged, low pitch" \
  --seed 42 --slug demo-voice --title "示例 · 台词"

# 2. 发布为 Studio Work
node /mods/neta/neta work init web works/audio/demo-voice --title "示例 · 台词"
node /mods/neta/neta work publish web works/audio/demo-voice

# 3. 转写素材
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py transcribe \
  --input meeting.mp4 --language zh
```

> 生成/转写前的参数细节见 `references/params.md`；声音属性组合见
> `references/voice-design.md`；发布与交付规范见 `references/studio-integration.md`。

## 质量检查清单

- [ ] 已读世界观并盘点：`world` 输出含角色/地点/事件与已有声线
- [ ] 已询问用户制作哪部分/哪个角色/哪段旁白，未擅自选段
- [ ] 角色已有声线时复用了绑定（engine+instruct+seed 一致）
- [ ] 新角色声线已写回材料（`bind` 子命令 / `content` 键 `声线`）；旁白已存 `narrator/binding.json`
- [ ] 生成成功：`works/audio/<slug>/` 下有 wav（+ mp3）+ index.html + tracks.json
- [ ] 播放页可打开，每个音轨可播放，可复现命令折叠区存在
- [ ] 已 `work init` + `work publish`，`meta.json` 为 `ready` 且有 `preview.url`
- [ ] 回复中交付了 Work 链接或文件路径，并附可复现命令
- [ ] 转写：json（词级时间戳）+ txt 都存在，文本预览与音频吻合
- [ ] 未把音乐/音效需求误接入本技能
- [ ] 已用真实目标跑通一次（本技能落地时已用世界角色验证）

## 资源

- `references/world-voice.md`：世界观适配工作流——读世界/理故事/盘点/询问/生成/回写全规范。
- `scripts/studio_tts.py world`：世界观声线盘点（读 manifest + 材料 + 已有语音作品，无需 TTS 环境）。
- `scripts/studio_tts.py bind`：把角色声线写回材料（content 键 `声线`），供后续生成自动复用。
- `references/params.md`：voice/transcribe 全部参数表与默认值。
- `references/voice-design.md`：design 模式属性类别、选项与常用组合。
- `references/models.md`：多引擎注册表、各模型下载方法、选型对比、注意事项。
- `references/studio-integration.md`：目录结构、work 发布、交付、错误处理、边界。
- `scripts/studio_tts.py`：唯一入口（setup/voice/transcribe/models/history/doctor）。
- `scripts/backends/`：外部引擎 runner（run_spark/run_qwen/run_f5）。
- `scripts/requirements*.txt`：各引擎依赖清单（requirements.txt 主环境 / -spark / -qwen / -f5），`models install` 按此安装。
- `scripts/tts_skill/`：vendored 上游包（精简，无 Web 服务）。
