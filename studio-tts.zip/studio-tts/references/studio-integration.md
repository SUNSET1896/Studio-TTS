# Studio 集成规范 — 产出、发布、交付、错误处理

本技能是 tts-skill（https://github.com/boommanpro/tts-skill，MIT，基于 OmniVoice
+ faster-whisper）的 **Studio 适配版**：保留 CLI 生成/转写核心，去掉 Web 服务与
React 前端；运行时 vendored 在技能目录 `scripts/` 下，自带 venv，输出落到
世界作品目录并发布为 Studio Work。

## 目录结构

```
/workspace/.agents/skills/studio-tts/
├── SKILL.md                 # 技能定义（何时调用）
├── references/
│   ├── params.md            # 参数表
│   ├── voice-design.md      # 声音属性参考
│   ├── models.md            # 多引擎注册表与下载方法
│   └── studio-integration.md # 本文档
└── scripts/
    ├── studio_tts.py        # Studio 适配入口（唯一需要调用的命令）
    ├── backends/            # 外部引擎 runner（run_spark/run_qwen/run_f5）
    ├── models/              # 外部引擎源码与权重（Spark-TTS-src / weights/）
    ├── requirements.txt     # 主环境依赖（omnivoice + ASR）
    ├── requirements-spark.txt / -qwen.txt / -f5.txt   # 各外部引擎依赖
    ├── .venv/               # 主环境（OmniVoice 引擎）
    ├── .venv-spark/         # Spark-TTS 独立环境
    ├── .venv-qwen/          # Qwen3-TTS 独立环境
    └── tts_skill/           # vendored 上游包（精简：无 server/webui/frontend）
```

## 产出位置

- 语音：`works/audio/<slug>/` —— `audio/*.wav`（原始产物）+ `audio/*.mp3`（网页播放）
  + `index.html`（播放页）+ `tracks.json`（程序化清单：文件名/seed/复现命令）
- 转写：`works/audio/transcribe_<时间戳>/` —— `.json`（词级时间戳）+ `.txt`
- 历史：`scripts/tts_skill.db`（SQLite，TTS/ASR 记录 + 音频库）

## 发布为 Studio Work（语音）

wrapper 只负责生成与页面；发布走 Studio 真实管线（需要 agent 执行，因为要
占用本回合的 placeholder 与 token）：

```bash
# 1. 生成（在 works/audio/<slug>/ 写内容与页面）
python3 /workspace/.agents/skills/studio-tts/scripts/studio_tts.py voice --text "..." --slug my-voice --title "..."

# 2. 初始化 work（创建 meta.json，占用画布 placeholder）
node /mods/neta/neta work init web works/audio/<slug> --title "<标题>"

# 3. 发布（写入 cohub work 记录，生成预览 URL）
node /mods/neta/neta work publish web works/audio/<slug>
```

> 若先 init 后生成，顺序可互换；init 只需在 publish 之前完成。
> 转写产物默认不发布为 Work，直接交付 txt/json 文件路径；若用户要页面再补建。

## 交付（agent 必须）

- 生成成功后，用 interaction-components 把作品/文件交到用户手上：
  - 已发布 → 交付 Work 链接（preview.url / 画布卡片）
  - 未发布 → 交付文件路径 `[xxx.wav](/workspace/works/audio/<slug>/audio/xxx.wav)`
- 同时在回复里给出该角色的**可复现命令**（播放页里也有），方便用户复现/续做。

## 多引擎说明

- 默认引擎 `qwen3-tts`（全部公开变体，免 token）；omnivoice 跑在主 `.venv`；
  其余引擎各自独立 venv + 独立 runner，依赖互不冲突（qwen-tts 会降级
  transformers 破坏 omnivoice，因此必须隔离）。
- 切回旧默认：`voice --model omnivoice ...`（CPU 直接可跑，无需 token）。
- `models install <ID>` 自动完成：建 venv → 装依赖（torch CPU + 模型包）→ 下载权重。
- qwen3-tts 权重全部公开（CustomVoice/Base，HF + 魔搭）；仅 0.6B-VoiceDesign 变体受限。
- cosyvoice2 / index-tts2 权重可从魔搭匿名拉取（iic/CosyVoice2-0.5B、IndexTeam/IndexTTS-2），
  但引擎仍需手动 conda/uv 环境；fish-speech 权重公开、引擎需 conda 3.12。
- cosyvoice2 / index-tts2 / fish-speech 无法在本技能 venv 内安装（conda/GPU/版本
  要求），`models install` 会打印精确的手动步骤，`voice --model` 调用时给指引。
- 每个外部引擎的可复现命令都带 `--model <ID>`。

| 症状 | 处理 |
|---|---|
| 首次运行任何命令 | 自动创建 venv 并安装（10–20 分钟），或先跑 `setup` |
| `voice` 报模型下载失败 | 已设 hf-mirror；重试一次；`doctor` 看设备/网络 |
| `transcribe` 报缺 faster-whisper | 跑 `setup --with_asr`（wrapper 会自动触发） |
| 生成全部失败 | 检查文本长度（≤5000 字）、参考音频是否存在；`history` 看错误 |
| 端口/内存问题 | CPU 推理较慢是正常的；短文本（≤100 字）单条约 1–3 分钟 |
| 可复现性漂移 | 必须同时固定 `--seed` 与全部参数；换设备（cuda↔cpu）结果不同 |

## 边界

- **不要**在本技能里启动 Web 服务/前端（已移除）。
- **不要**把语音生成当音乐生成：配乐/环境音走 `neta generate audio`（suno）。
- 声音克隆需要用户提供 3–10 秒参考音频；没有参考音频时用 design 模式。
- 技能不含任何世界具体内容：角色台词、旁白文本、参考音频全部由调用方传入。
