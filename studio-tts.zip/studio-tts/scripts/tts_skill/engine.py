"""TTS 生成引擎：模型加载、单次/批量生成、声音设计属性。

从原 webui.py 抽离的核心逻辑，不依赖任何 UI 框架，
供 server.py / infer.py / webui.py 复用。

设计要点：
- 模型缓存 _MODEL_CACHE 使用 threading.Lock 保护，避免并发重复加载（缺点10）
- _do_batch_generate 支持可选的进度回调，用于 SSE 进度反馈（缺点3）
- 文本长度上限 MAX_TEXT_LENGTH，防止超长文本拖垮推理（缺点10）
"""

from __future__ import annotations

import logging
import threading
import time
from pathlib import Path
from typing import Any, Callable, Optional

from tts_skill.config import create_record
from tts_skill.utils import (
    detect_torch_device,
    fix_random_seed,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# 统一常量
# ---------------------------------------------------------------------------

# 单次批量生成的最大数量（与前端预创建的播放器数量对齐）
MAX_BATCH = 5

# 文本长度上限（字符数），防止超长文本拖垮推理与占用过多显存
MAX_TEXT_LENGTH = 5000


# ---------------------------------------------------------------------------
# 声音设计属性选项（对齐 omnivoice/cli/demo.py）
# ---------------------------------------------------------------------------

_DESIGN_CATEGORIES: dict[str, list[str]] = {
    "性别 / Gender": ["Auto", "男 / Male", "女 / Female"],
    "年龄 / Age": [
        "Auto",
        "儿童 / Child",
        "少年 / Teenager",
        "青年 / Young Adult",
        "中年 / Middle-aged",
        "老年 / Elderly",
    ],
    "音调 / Pitch": [
        "Auto",
        "极低音调 / Very Low Pitch",
        "低音调 / Low Pitch",
        "中音调 / Moderate Pitch",
        "高音调 / High Pitch",
        "极高音调 / Very High Pitch",
    ],
    "风格 / Style": ["Auto", "耳语 / Whisper"],
    "英文口音 / English Accent": [
        "Auto",
        "美式口音 / American Accent",
        "英式口音 / British Accent",
        "澳大利亚口音 / Australian Accent",
        "加拿大口音 / Canadian Accent",
        "印度口音 / Indian Accent",
        "中国口音 / Chinese Accent",
        "日本口音 / Japanese Accent",
        "韩国口音 / Korean Accent",
        "葡萄牙口音 / Portuguese Accent",
        "俄罗斯口音 / Russian Accent",
    ],
    "中文方言 / Chinese Dialect": [
        "Auto",
        "河南话",
        "陕西话",
        "四川话",
        "贵州话",
        "云南话",
        "桂林话",
        "济南话",
        "石家庄话",
        "甘肃话",
        "宁夏话",
        "青岛话",
        "东北话",
    ],
}


def build_instruct_from_selections(selections: list[str]) -> Optional[str]:
    """从下拉选择构建 instruct 字符串。

    选项格式为 "中文 / English"：
    - 普通属性取英文部分（如 "男 / Male" -> "Male"）
    - 方言类取中文部分（如 "四川话" 无 " / "，直接保留）
    """
    parts = []
    for sel in selections:
        if not sel or sel == "Auto":
            continue
        if " / " in sel:
            zh, en = sel.split(" / ", 1)
            if "话" in zh:
                parts.append(zh.strip())
            else:
                parts.append(en.strip())
        else:
            parts.append(sel.strip())
    return ", ".join(parts) if parts else None


# ---------------------------------------------------------------------------
# 模型加载（线程安全缓存）
# ---------------------------------------------------------------------------

_MODEL_CACHE: dict[str, Any] = {}
_MODEL_CACHE_LOCK = threading.Lock()


def get_model(model_name: str, device: Optional[str] = None):
    """加载并缓存模型（线程安全）。

    使用锁避免并发请求触发重复加载同一模型。
    """
    cache_key = f"{model_name}|{device}"
    # 双重检查：先无锁查询，命中则直接返回
    if cache_key in _MODEL_CACHE:
        return _MODEL_CACHE[cache_key]

    with _MODEL_CACHE_LOCK:
        # 持锁后再次检查，防止排队期间已被其他线程加载
        if cache_key in _MODEL_CACHE:
            return _MODEL_CACHE[cache_key]

        import torch

        from omnivoice import OmniVoice

        resolved_device = device or detect_torch_device()

        logger.info("加载模型 %s (device=%s)...", model_name, resolved_device)
        # CPU 上不支持 float16 推理（half 算子缺失），自动回退 float32
        dtype = torch.float32 if resolved_device == "cpu" else torch.float16
        model = OmniVoice.from_pretrained(
            model_name,
            device_map=resolved_device,
            dtype=dtype,
        )
        _MODEL_CACHE[cache_key] = model
        return model


# ---------------------------------------------------------------------------
# 生成核心逻辑
# ---------------------------------------------------------------------------

# 进度回调签名：(current_index, total, seed, status_text) -> None
ProgressCallback = Callable[[int, int, int, str], None]


def generate_audio(
    model,
    *,
    text: str,
    mode: str,
    ref_audio: Optional[str],
    ref_text: Optional[str],
    instruct: Optional[str],
    language: Optional[str],
    seed: int,
    num_step: int,
    speed: float,
    duration: Optional[float],
    guidance_scale: float,
    t_shift: float,
    denoise: bool,
    postprocess_output: bool,
    normalize_text: bool,
):
    """执行单次生成，返回 (audio_np, sample_rate)。"""
    fix_random_seed(seed)

    kwargs = {
        "text": text.strip(),
        "language": language if language else None,
        "num_step": int(num_step),
        "guidance_scale": float(guidance_scale),
        "t_shift": float(t_shift),
        "denoise": bool(denoise),
        "postprocess_output": bool(postprocess_output),
        "normalize_text": bool(normalize_text),
    }
    if speed is not None and float(speed) != 1.0:
        kwargs["speed"] = float(speed)
    if duration is not None and float(duration) > 0:
        kwargs["duration"] = float(duration)

    if mode == "clone":
        if not ref_audio:
            raise ValueError("请上传参考音频")
        kwargs["ref_audio"] = ref_audio
        kwargs["ref_text"] = ref_text if ref_text else None
    elif mode == "design":
        if not instruct:
            raise ValueError("请选择至少一个声音属性")
        kwargs["instruct"] = instruct

    audio = model.generate(**kwargs)
    return audio[0], model.sampling_rate


def do_batch_generate(
    model,
    *,
    text: str,
    mode: str,
    ref_audio: Optional[str],
    ref_text: Optional[str],
    instruct: Optional[str],
    language: Optional[str],
    base_seed: int,
    batch_count: int,
    num_step: int,
    speed: float,
    duration: Optional[float],
    guidance_scale: float,
    t_shift: float,
    denoise: bool,
    postprocess_output: bool,
    normalize_text: bool,
    output_dir: Path,
    name: Optional[str] = None,
    progress: Optional[ProgressCallback] = None,
):
    """批量生成并保存，返回 (record, output_files, audio_samples, errors)。

    Args:
        progress: 可选的进度回调，在每个批次项开始/结束时调用。
    """
    import numpy as np
    import soundfile as sf

    batch_count = max(1, batch_count)
    batch_seeds = [base_seed + i for i in range(batch_count)]
    output_files: list[str] = []
    audio_samples: list[tuple[int, np.ndarray]] = []
    errors: list[str] = []

    timestamp = time.strftime("%Y%m%d_%H%M%S")

    for i, seed in enumerate(batch_seeds):
        if progress is not None:
            progress(i, batch_count, seed, "generating")
        try:
            audio, sr = generate_audio(
                model,
                text=text,
                mode=mode,
                ref_audio=ref_audio,
                ref_text=ref_text,
                instruct=instruct,
                language=language,
                seed=seed,
                num_step=num_step,
                speed=speed,
                duration=duration,
                guidance_scale=guidance_scale,
                t_shift=t_shift,
                denoise=denoise,
                postprocess_output=postprocess_output,
                normalize_text=normalize_text,
            )
            suffix = f"_{i}" if batch_count > 1 else ""
            filename = f"{mode}_{timestamp}{suffix}_seed{seed}.wav"
            output_path = output_dir / filename
            sf.write(str(output_path), audio, sr)
            output_files.append(str(output_path))
            audio_samples.append((sr, audio))
            if progress is not None:
                progress(i + 1, batch_count, seed, "done")
        except Exception as e:
            errors.append(f"[seed={seed}] {type(e).__name__}: {e}")
            logger.exception("生成失败 seed=%d", seed)
            if progress is not None:
                progress(i + 1, batch_count, seed, "error")

    if not output_files:
        raise RuntimeError("所有生成均失败: " + "; ".join(errors))

    # 创建历史记录
    record = create_record(
        mode=mode,
        text=text,
        ref_audio=ref_audio,
        ref_text=ref_text,
        instruct=instruct,
        language=language,
        seed=base_seed,
        num_step=num_step,
        speed=speed,
        duration=duration,
        guidance_scale=guidance_scale,
        t_shift=t_shift,
        denoise=denoise,
        postprocess_output=postprocess_output,
        normalize_text=normalize_text,
        batch_count=batch_count,
        batch_seeds=batch_seeds,
        output_files=output_files,
        device=str(model.device),
        name=name,
    )

    return record, output_files, audio_samples, errors


# ---------------------------------------------------------------------------
# 向后兼容别名（原 webui.py 内部命名，保留以减少破坏性改动）
# ---------------------------------------------------------------------------

# 这些下划线前缀的别名供 webui.py / 旧测试在过渡期继续使用。
_get_model = get_model
_generate_audio = generate_audio
_do_batch_generate = do_batch_generate
_build_instruct_from_selections = build_instruct_from_selections
