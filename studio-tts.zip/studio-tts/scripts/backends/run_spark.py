#!/usr/bin/env python3
"""Spark-TTS 后端 runner。由 .venv-spark/bin/python 执行。

用法: python run_spark.py <args.json> <output.wav>

args.json 字段:
  text       必填，要合成的文本
  instruct   可选，声音属性描述（gender/pitch/speed 从中解析）
  ref_audio  可选，参考音频路径（克隆）
  ref_text   可选，参考音频文本
  seed       可选，随机种子
  device     可选，cpu/cuda
  model_dir  可选，权重目录（默认 scripts/models/weights/Spark-TTS-0.5B）
  temperature/top_k/top_p  采样参数
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import torch

SCRIPTS = Path(__file__).resolve().parent.parent
SPARK_SRC = SCRIPTS / "models" / "Spark-TTS-src"
sys.path.insert(0, str(SPARK_SRC))

PITCH_MAP = {
    "very low": "very_low", "low": "low", "moderate": "moderate",
    "high": "high", "very high": "very_high",
}


def parse_instruct(instruct: str | None) -> tuple[str | None, str | None, str | None]:
    """从属性描述解析 Spark 支持的 gender/pitch/speed。"""
    if not instruct:
        return None, None, None
    ins = instruct.lower()
    gender = None
    if "female" in ins or "女" in ins:
        gender = "female"
    elif "male" in ins or "男" in ins:
        gender = "male"
    pitch, speed = None, None
    for k, v in PITCH_MAP.items():
        if k in ins and ("pitch" in ins or "音调" in ins or "调" in ins):
            pitch = v
        if k in ins and ("speed" in ins or "语速" in ins or "速" in ins):
            speed = v
    return gender, pitch, speed


def main() -> int:
    args = json.load(open(sys.argv[1], encoding="utf-8"))
    out_path = sys.argv[2]
    model_dir = args.get("model_dir") or str(SCRIPTS / "models" / "weights" / "Spark-TTS-0.5B")
    if not Path(model_dir).is_dir():
        print(json.dumps({"ok": False, "error": f"Spark-TTS 权重不存在: {model_dir}，请先运行 models install spark-tts"}))
        return 1
    device = torch.device(args.get("device") or "cpu")
    if args.get("seed") is not None:
        torch.manual_seed(int(args["seed"]))
        import numpy as np

        np.random.seed(int(args["seed"]))

    from cli.SparkTTS import SparkTTS

    model = SparkTTS(Path(model_dir), device=device)
    gender, pitch, speed = parse_instruct(args.get("instruct"))
    if args.get("instruct") and any([gender, pitch, speed]):
        # process_prompt_control 要求三项齐全，缺省补默认值
        gender = gender or "male"
        pitch = pitch or "moderate"
        speed = speed or "moderate"
    elif not args.get("ref_audio"):
        print(json.dumps({"ok": False, "error": "Spark-TTS 需要声音属性（design，如 --instruct 'male, low pitch'）或参考音频（clone）"}))
        return 1
    wav = model.inference(
        text=args["text"],
        prompt_speech_path=args.get("ref_audio") or None,
        prompt_text=args.get("ref_text") or None,
        gender=gender,
        pitch=pitch,
        speed=speed,
        temperature=float(args.get("temperature", 0.8)),
        top_k=int(args.get("top_k", 50)),
        top_p=float(args.get("top_p", 0.95)),
    )
    audio = wav.detach().cpu().numpy().squeeze() if isinstance(wav, torch.Tensor) else __import__("numpy").asarray(wav).squeeze()
    import soundfile as sf

    sr = 16000
    sf.write(out_path, audio, sr)
    print(json.dumps({"ok": True, "sr": sr, "duration": round(len(audio) / sr, 3)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
